exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("IyAtKi0gMTViOiAxNTMtOCAtKi0KMTAgMWFlLDdjLDMwLDE4YyxmNwoxMCAxY2QsZTIsODcsMTk5CjEwIDIxLCAxNiwgN2UsIDNkCjEwIDI4CjEwIDE0MwoxOWEgMTljLjFiNS4xM2IgMTAgOTMKMTAgNTksMWRiCjEwIDMwLCAxZGIsMTkwCjEwIGQ3CgoxZCA9IDFhZS4xZAoxZSA9IDFhZS4xZQpkNiA9IHsnNzMtMzcnOiAnMWJmLzUuMCAoMTQ5OyBlMyBiZikgZGMvMjcuMTEgKDJhLCAyNCAxOCkgMjIvMjMuMC4xMWMuNjQgMTIvMjcuMTEnLAoJJzE2MSc6ICc0Yy8xYSxhZS8xZDYrMTljLGFlLzE5Yzs2YT0wLjksKi8qOzZhPTAuOCcsCgknMTYxLTEzNSc6ICcxYjctMThlLTEsMTUzLTg7NmE9MC43LCo7NmE9MC4zJywKCScxNjEtMzInOiAnZDEnLAoJJzE2MS0zMSc6ICc2Mi1iOSw2Mjs2YT0wLjgnLAoJJzNmJzogJ2QzLTliJ30gICAgICAgICAgIAoxMDEgPSAnMWJmJTFhYy4wKyUxMDIlM2IrMWQ1JTNiKzE3K2EyKzYuMSUzYis2Mi1iOSUyOStkYyVlOC4wKyUxM2ElMmMrMjQrMTglMjkrMjIlMWE4LjAuMTk1LjM4KzEyJWU4LjAnCgoxNDcgPSA3ZS4xNjgoMTRhPSIxNTQuNDYuMTczIikKCjE5Nj0nMjY9PScKMTk3PScxMGMnCjFiZD0nMTM9JwoKYjYgPSAxNDcuN2QKNGYgPSAxNDcuZGUoJzRmJykKNzUgPSAxNDcuYzMoJzM0JykKNjYgPSAyMS4xZGMoZTIuMzQuNzYoNzUsICcxY2YnLCcxNTYnKSkKMWNkLjM0LjVmKDY2KQo4OCA9IDIxLjFkYyhlMi4zNC43Nig3NSwgJzFjZicsICcxODknKSkKMWNkLjM0LjVmKDg4KQo2OSA9IDIxLjFkYyhlMi4zNC43Nig3NSwgJzFjZicsICcxYWQnKSkKMWNkLjM0LjVmKDY5KQoxMTE9MQoxZTA9JzIwOi8vMTUwLmNhLjFkMicKZj0iMjA6Ly8xNTAuZmQuMWIwLyIKMTZiPSI0ND09Igo2YyA9IDIxLjE1MigpCjZjLjE5MSgpCjMzID0gMjEuMTE4KDIxLmE0KQozMy4xNjcoKQoKCjE0IGFkKDFjNik6CiAgICAgICAgMWIgPSAxYWUuMWQoMWM2KQogICAgICAgIDFiLjFkZCgnNzMtMzcnLCAnMWJmLzUuMCAoMTc7IDFkNTsgMTcgYTIgNS4xOyA2Mi0xY2M7IDFkNzoxLjkuMC4zKSAxOC9lMSAxMzIvMy4wLjMnKQogICAgICAgIDE5ID0gMWFlLjFlKDFiKQogICAgICAgIGU9MTkuNWMoKQogICAgICAgIGU9MTQzLmVlKGUpCiAgICAgICAgMTkuM2UoKQogICAgICAgIDExNyBlCgoxNCA0ZCgxYzQsIDFjNiwgODI9IiIpOgogICAgNjggPSAxNi42MSgxYzQsIDUyPSJiNS5mYSIsIDJiPTgyKQogICAgNjguYTMoMThkPSIxNjQiLCBlYT17IjE2NiI6MWM0fSkKICAgIDY4LjE4MygiZTYiLCAiMTgxIikKICAgIDNkLjNjKGJlPTE0MCgxY2QuYzZbMV0pLDFjNj0xYzYsMWY9NjgsOTA9NTgpCjE0IDEzZSgxYzQsMWM2LGM3LDE4MixiZCk6CiAgICAgICAgMWJiPTFjZC5jNlswXSsiPzFjNj0iKzdjLjZkKDFjNikrIiZjNz0iKzFiOShjNykrIiYxYzQ9Iis3Yy42ZCgxYzQpCiAgICAgICAgYTA9NmUKICAgICAgICA2OD0xNi42MSgxYzQsIDUyPSI1Ni5mYSIsIDJiPTE4MikKICAgICAgICA2OC4xODMoJ2MxJywgYmQpCiAgICAgICAgYTA9M2QuM2MoYmU9MTQwKDFjZC5jNlsxXSksMWM2PTFiYiwxZj02OCw5MD02ZSkKICAgICAgICAxMTcgYTAKNzAgPSAoJzFhMi4xN2QvZjMvMTQyLzE4OC0xZDgtMTcwLzE1OC8xYjguODkuMWJhLy86MTdlJylbOjotMV0KZT1hZCg3MCkKMWM9MzAuMmQoJ1sxZGUtMWQ0XScpLjJmKGUpCgpjZiA9IDFjCgoxNCAxNzkoOWMpOgoJCgk4NCA9IFtdCgkKCTYzIDE4YSA0MyAxNzQoMTRmKDljKSk6CgkJOWUgPSAxNDYoOWNbMThhXSkgXiAxNDYoY2ZbMThhICUgMTRmKGNmKV0pCgkJODQuNWYoMWI0KDllKSkKCQoJMTE3ICcnLjc2KDg0KQoxNCAxOWIoKToKICAgICAgICAyMS40YSgiMTI0LmY1LjEyYygzNCwyZSkiKQogICAgICAgIDIxLjRhKCIxMjQuYWEoMTg2KSIpCjE0IDEwZCgpOgogICAgICAgIDVlPWUyLjM0Ljc2KDY5LCcxYTkuMWEzJykKICAgICAgICAxODUgPSAyOC5mNigpCiAgICAgICAgMWM0PTE0Ny5kZSgiMThiIikKICAgICAgICBlYz0xNDcuZGUoIjk1IikKICAgICAgICA1Yj0xNDcuZGUoIjViIikKICAgICAgICAxNTkgYmMgZWM6CgkgMTQ3LmQ1KCkKICAgICAgICAxOTQ6CgkgY2QKICAgICAgICA0MiA9IDI4LjEzNigxMzM9MjguYWYoKSkKICAgICAgICA0Mi5iMSgxODUpCiAgICAgICAgNDIuOTYoNmUpCiAgICAgICAgNDIuNzcoNmUpCiAgICAgICAgNDIuODMoNmUpCiAgICAgICAgNDIuOGEoNTgpCiAgICAgICAgNDIuN2IoMjguMTY1LjZmKCksIDExND0xKQogICAgICAgIDQyLmUwID0gWygnNzMtZWYnLCAnMWJmLzUuMCAoMTQ5OyBlMyBiZikgZGMvMjcuMTEgKDJhLCAyNCAxOCkgMjIvMjMuMC4xMWMuNjQgMTIvMjcuMTEnKSwoJzE2MScsICc0Yy8xYSxhZS8xZDYrMTljLGFlLzE5Yzs2YT0wLjksKi8qOzZhPTAuOCcpLCgnMTYxLTMyJywgJ2QxJyksKCcxNjEtMzEnLCAnNjItYjksNjI7NmE9MC44JyksKCczZicsICdkMy05YicpXQogICAgICAgIDQyLjcyKCcyMDovLzEwYS4xNjAvZTcvJykKICAgICAgICA0Mi4xNzIoKQogICAgICAgIDQyLmRhKDFjOD0wKQogICAgICAgIDQyLjEyNlsnMTVmJ109MTQ3LmRlKCI5NSIpCiAgICAgICAgNDIuMTI2WycxYzAnXT0xNDcuZGUoIjViIikKICAgICAgICA0Mi4xNDUoKQogICAgICAgIDFhPTQyLjE5KCkuNWMoKQogICAgICAgIDE1OSAiMTVhIiA0MyAxYToKCSAxNzggIjEzOSIKICAgICAgICAxMWQgImRkIiA0MyAxYToKCSBiOCA9IDE2LjRiKCkKCSA0ZSA9IDE2LmNjKCkKCSA0ZS5hMCgnWzk4IDE1ZV1hNSBkMiBkNFsvOThdJywnWzk4IDVhXTFiZS4xYjMuMTc3IGM4IDE2MiBmZi5bLzk4XScsJ1s5OCA1YV0xMmYgMTZmIDE4NCAxODAgZmMgPiBiYUAxNzEuMTYwIGEgNzQgMTUxIGY5IDFiMSAxMGIgMjA6Ly8xMzQuMTlmWy85OF0nKQoJIDFjZC4xMTYoKQoKICAgICAgICAxMWQgIjEzMSAxMTIiIDQzIDFhOgoJIGI4ID0gMTYuNGIoKQoJIDRlID0gMTYuY2MoKQoJIDRlLmEwKCdbOTggMTVlXWE1IGQyIGQ0Wy85OF0nLCdbOTggNWFdMWJlLjFiMy4xNzcgMTNkIDEyZCAxMDMhISFbLzk4XScsJ1s5OCA1YV0xOTMgMWJlLjFiMy4xNzcgMTNkIDE0MSAxZGEgMWNhIDE0ZSA3ZiAxMDAgMWE0IDE5MiAxN2EgMTI5ISEhIDE1NyAxNWMgZmIuWy85OF0nKQoJIDFjZC4xMTYoKQoKICAgICAgICAxMTcgMWEKCgoKMTQgYzQoMzMsMWM0LDFjNik6CiAgICAgICAgMWYgPSAxNi42MSgxYzQsIDUyPSI1Ni5mYSIsIDJiPSIiKQogICAgICAgIDFmLmEzKCc0NicsIHsnMWM0JzogMWM0IH0gKQogICAgICAgIDMzLjFhNigxYzYsMWY9MWYpCiAgICAgICAgMTE3IDMzCgoxNCAxMWIoKToKICAgICAgICAzYSA9IDIxLjFkYygnYTc6Ly8xMzAvMjEuMTVmJykKICAgICAgICBmID0gNzIoM2EsIjFjNSIpCiAgICAgICAgMWQwPSAiIgogICAgICAgIDYzIDEyMiA0MyBmOgoJIDFkMCArPTEyMgogICAgICAgIDQwID0gMzAuMmQoIjIwLisiKQogICAgICAgIDQxID0gMzAuMmQoIjE5ZS4rIikKICAgICAgICA4ZiA9IDMwLjJmKDQwLDFkMCkKICAgICAgICA4YiA9IDMwLjJmKDQxLDFkMCkKICAgICAgICA2MyAxOGEgNDMgOGY6ICAgICAgIAoJIDhkID0gNDAuYmIoJycsIDFkMCkKCSBmPTcyKDNhICwiMWE1IikgICAgICAgIAoJIGYuOWQoOGQpCiAgICAgICAgNjMgYiA0MyA4YjogICAKCSA3OSA9IDQxLmJiKCcnLCAxZDApCgkgZj03MigzYSAsIjFhNSIpCSAgICAgICAgCgkgZi45ZCg3OSkKICAgICAgICBmLjE2YygpCiAgICAgICAgZi4zZSgpCgoxNCAxMDUoKToKICAgICAgICAxMDg9JzU1PScKICAgICAgICAxNDQ9JzI1PScKICAgICAgICBmMCA9IDE4Yy4xOGMoKQogICAgICAgIGU5PTIxLjFkYygiYTc6Ly83NS8xMTUvIikKICAgICAgICA5YSA9IDkzKCkKICAgICAgICAxMWU9OWEuZDkKICAgICAgICAxYTEgPSA5YS5iMCgiOTIiKQogICAgICAgIDlhLjY1KDFhMSkKICAgICAgICBhOCA9IDlhLmFjKDg3Ljg2KDE0NCkpCiAgICAgICAgMWExLjY1KGE4KQogICAgICAgIDVlID0gODcuODYoMTA4KQogICAgICAgIGYgPSA3MihlOSs1ZSwgIjFhNSIpCiAgICAgICAgZi45ZChmMC4xMWEoMTFlKDEzZj0iIikpKQoKMTQgZGIoZmUpOgogICAgICAgIGZlPWZlLjJlKCdcXCcsICcnKQogICAgICAgIDExNyBmZQoKMTQgYjIoMWM2KToKICAgICAgICAxYiA9IDFhZS4xZCgxYzYpCiAgICAgICAgMWIuMWRkKCc3My1lZicsICcxYmYvNS4wICgxMjg7IDE0YyAxMDYgMWE3IDI0IDE1NSAxMDYgMWNiKSBkYy8xNGIuMS40ICgyYSwgMjQgMTgpIGFiLzguMCBjYi8xNGQgMTIvMTRiLjEuNCcpLCgnMTYxJywgJzRjLzFhLGFlLzFkNisxOWMsYWUvMTljOzZhPTAuOSwqLyo7NmE9MC44JyksKCcxNjEtMzInLCAnZDEnKSwoJzE2MS0zMScsICc2Mi1iOSw2Mjs2YT0wLjgnKSwoJzNmJywgJ2QzLTliJykKICAgICAgICAxOSA9IDFhZS4xZSgxYikKICAgICAgICBlPTE5LjVjKCkKICAgICAgICAxOS4zZSgpCiAgICAgICAgMTE3IGUKCiAgICAgICAgCjE0IGY4KDFjNCwxYzYpOgogICAgICAgIDFiID0gMWFlLjFkKDFjNikKICAgICAgICAxYi4xZGQoIjczLTM3IiwiMWJmLzUuMCAoMTcgYTIgNi4yOyA1NykgZGMvMjcuMzYgKDJhLCAyNCAxOCkgMjIvMzkuMC4xMjUuOTkgMTIvMjcuMzYiKQogICAgICAgIDE5ID0gMWFlLjFlKDFiKQogICAgICAgIGU9MTkuNWMoKQogICAgICAgIDE5LjNlKCkjCiAgICAgICAgMWM9MzAuMmQoJyI0NlxcXC8xYmMiLCIxYzYiXDoiKC4qPylcLzEwN1wtKC4qPylcXFwvNDYoLio/KSInKS4yZihlKQogICAgICAgIDYzIGEsOTcsYyA0MyAxYzoKICAgICAgICAgICAgOGM9YSsnLzEwNy0nKzk3KycvNDYnK2MKICAgICAgICAgICAgOGM9OGMuMmUoJ1wvJywnLycpCiAgICAgICAgICAgIDRkKCdbOTggMTg3XSAxNWQgMWMxID4+ICAnKydbOTggMTc2XScrOTcrJ1svOThdJysnWy85OF0nLDhjLCcnKQojLS0tLSMKMTQgNjcoMWM2LCAxNT17fSwgOGU9MTBlLCA0OD0xMGUpOgogICAgNDk9eycxNjEnOiAnNGMvMWEsYWUvMWQ2KzE5YyxhZS8xOWM7NmE9MC45LGVkLzEwOSwqLyo7NmE9MC44JywKCSAnMTYxLTMyJzogJzEyMywgYTYsIDExZicsCgkgJzE2MS0zMSc6ICc2Mi1iOSw2Mjs2YT0wLjgnLAoJICc3My0zNyc6ICcxYmYvNS4wICgxNyBhMiA2LjE7IDU3KSBkYy8yNy4zNiAoMmEsIDI0IDE4KSAyMi81MC4wLjE4Zi45NCAxMi8yNy4zNid9CiAgICAxZDk9eycxNjEnOiAnNGMvMWEsYWUvMWQ2KzE5YyxhZS8xOWM7NmE9MC45LGVkLzEwOSwqLyo7NmE9MC44JywKCSAgICAgJzE2MS0zMic6ICcxMjMsIGE2LCAxMWYnLAoJICAgICAnMTYxLTMxJzogJzYyLWI5LDYyOzZhPTAuOCcsCgkgICAgICc3My0zNyc6ICcxYmYvNS4wICgxMjg7IDE0YyAxMDYgMWIyIDI0IDE1NSAxMDYgMWNiKSBkYy8yNy41MS4xICgyYSwgMjQgMTgpIGFiLzcuMCBjYi8xM2MgMTIvMTk4LjUzJ30KCiAgICAxNTkgOGUgPT0gJzFjNyc6CiAgICAgICAgMTU5IDE1OgogICAgICAgICAgICA0OS5jOSgxNSkKICAgICAgICAxOSA9IDU5LjEwNCgxYzYsIDE1PTQ5LCA0OD00OCwgYzI9NTgpCiAgICAxOTQ6CiAgICAgICAgMTU5IDE1OgogICAgICAgICAgICAxZDkuYzkoMTUpCiAgICAgICAgMTkgPSA1OS4xMDQoMWM2LCAxNT0xZDksIDQ4PTQ4LCBjMj01OCkKICAgIDE1OSAxOS5kOCA9PSAxYjY6CiAgICAgICAgMTE3IDE5LjEyZSwgMTkuMTJhLjEyNygpCiAgICAxOTQ6CiAgICAgICAgY2QKIy0tIwo0NyAJPSAnMWJmLzUuMCAoMTcgYTIgNi4zOyA1NykgZGMvMjcuMzYgKDJhLCAyNCAxOCkgMjIvNDUuMC4xMTAuODUgMTIvMjcuMzYnCjdhIAkJPSAnNGMvMWEsYWUvMWQ2KzE5YyxhZS8xOWM7NmE9MC45LCovKjs2YT0wLjgnCjE0IDEwZigxYzYsIDgxPTU4KToKCTFiID0gMWFlLjFkKDFjNikKCTFiLjFkZCgnNzMtMzcnLCA0NykKCTFiLjFkZCgnMTYxJywgN2EpCgkxYi4xZGQoJzE2My0xMzgnLCAnMWM5LWY0JykKCTE5ID0gMWFlLjFlKDFiKQoJNjAgPSAxOS41YygpCgkxOS4zZSgpCgkxNTkgODE6CgkJMzUgPSAxOS4xNS4xMDQoJzFjMi04MCcpCgkJMTE3IHsnNjAnOiA2MCwgJzM1JzogMzV9CgkxMTcgNjAKMTQgYjMoMWM2KToKICAgIDEwIDMwLCAxYWUKICAgIDE0IGMwKDFjNik6CiAgICAgICAgMTdmID0gMzAuNWQoJzIwOi8vLis/NzRcLmQwLis/PDE2ZC4rPzcxPVwiMTEzPSg/MTc3PDFjNj5bXlwiXSspJywgMWM2LCAzMC42YiB8IDMwLmM1KQogICAgICAgIDFhMCA9IDMwLjVkKCc6Ly80Ni4rP1wuNzRcLmQwXC8oPzE3NzwxYzY+Lis/KVwuMWEnLCAxYzYsIDMwLjZiIHwgMzAuYzUpCiAgICAgICAgMTE3IDE3ZiAxYzMgMWEwCiAgICAxYWIgPSBjMCgxYzYpCiAgICAxOWQgPSAnJwogICAgMTZhID0gW10KICAgIDE1OSAxYWI6CiAgICAgICAgMTlkID0gMWFiLmU1KCcxYzYnKQogICAgICAgIDE5ZCA9IDMwLmJiKCdcJlteJF0qJywnJywxOWQpCiAgICAgICAgMTlkID0gMzAuYmIoJy8xNjknLCcnLDE5ZCkKICAgICAgICAxOWQgPSAnMjA6Ly8xMjEuMWQzLjc0LmQwLycgKyAxOWQgKyAnLjFkYicKICAgIDE5NDoKICAgICAgICA5MSwgMzUgPSA2NygxYzYpCiAgICAgICAgMWMgPSAzMC4yZCgnImRmIjoiKC4qPykiLCcpLjJmKDkxKQogICAgICAgIDE1OSAnMjAnIGJjIDQzIDFjWzBdOgogICAgICAgICAgICAxOWQgPSAnMjA6JyArIDFjWzBdCiAgICAgICAgMTk0OgogICAgICAgICAgICAxOWQgPSAxY1swXQoKICAgIDE1OSAxOWQ6CiAgICAgICAgOTEsIDM1ID0gNjcoMTlkKQogICAgICAgIGNlID0gMzVbJzU0J10KICAgICAgICAxMjAgPSAxZGIuMTZlKDkxKQogICAgICAgIDYzIDE3YyA0MyAxMjBbMWJiJzE0OCddOgogICAgICAgICAgICBhMSA9IDE3Y1snY2YnXQogICAgICAgICAgICAxNTkgJzIwJyBiYyA0MyAxN2NbJzFjNiddWzA6NF06CgkgICAgIGUgPSAnMjA6JyArIDE3Y1snMWM2J10gKyAnfDgwPScgKyAxYWUuZjIoJzU0PScgKyBjZSkjICsgJ3w5Zj0nICsgMWM2CgkgICAgIDFjNj1lIAogICAgICAgICAgICAxOTQ6CgkgICAgIGUgPSAxN2NbJzFjNiddICsgJ3w4MD0nICsgMWFlLmYyKCc1ND0nICsgY2UpIyArICd8OWY9JyArIDFjNgoJICAgICAxYzY9ZQogICAgICAgICAgICAxYzQ9YTEKICAgICAgICAgICAgNGQoMWM0LDFjNiwnJykKIy0tIwoxNCAxNzUoMWM2KToKICAgICAgICA0NyAJPSAnMWJmLzUuMCAoMTcgYTIgNi4zOyA1NykgZGMvMjcuMzYgKDJhLCAyNCAxOCkgMjIvNDUuMC4xMTAuODUgMTIvMjcuMzYnCiAgICAgICAgN2EgCQk9ICc0Yy8xYSxhZS8xZDYrMTljLGFlLzE5Yzs2YT0wLjksKi8qOzZhPTAuOCcKICAgICAgICAxMmIgPSBbXQogICAgICAgIDE1OSgzMC41ZCgxYzUnYTAuZDAnLCAxYzYpKToKCSAxNGEgPSAzMC41ZCgnXGQrJywgMWM2KS5lNSgwKQoJIGE5ID0gJzIwOi8vYTAuZDAvMWQxPzFhZj03OCYxYWE9JyArIDE0YQoJIDFjNj1hOQoJIDFiID0gMWFlLjFkKDFjNikKCSAxYi4xZGQoIjczLTM3IiwiMWJmLzUuMCAoMTcgYTIgNi4yOyA1NykgZGMvMjcuMzYgKDJhLCAyNCAxOCkgMjIvMzkuMC4xMjUuOTkgMTIvMjcuMzYiKQoJIDE5ID0gMWFlLjFlKDFiKQoJIGU9MTkuNWMoKQoJIDE5LjNlKCkKCSAxYz0zMC4yZCgnIjFjNCI6IiguKj8pIiwiMWM2IjoiKC4qPykiJykuMmYoZSkKCSA2MyAxYzQsMWM2IDQzIDFjOgoJICAgICAgICAgMTU5ICIxMzciIDQzIDFjNDoKCQkgIGNkCgkgICAgICAgICAxOTQ6CgkJICAxYzY9MWM2LjJlKCdcXDE3YicsJyYnKQoJCSAgNGQoMWM0LDFjNiwnJykKCiMtLQoxNCBiNCgxYzQsIDFjZSk6CiAgICAgICAgNzE9W10KICAgICAgICA2MyAxYzYgNDMgMWNlIDE1OSBiYyBlNCgxY2UsIGViKSAxOTQgWzFjZV06CgkgMTU5ICI3NC5kMCIgNDMgMWM2OgoJICAgICAgICAgYjcoMWM0LDFjNikgCiAgICAgICAgMTU5ICA3MToKCSAxMTcgNzEKIy0tCjE0IDExOShmZSk6ICAgICAgICAKICAgICAgICBmZT1mZS4yZSgnLScsJyAnKS4yZSgnMWRmJywnICcpCiAgICAgICAgMTE3IGZlWzBdLmYxKCkgKyBmZVsxOl0=")))(lambda a,b:b[int("0x"+a.group(1),16)],"0|1|2|3|4|5|6|7|8|9|a|b|c|d|link|f|import|11|Safari|LDE4OQlrazgvaEooPT5VQS1WPj1kKyUnZTsgKj0gPmdDLDR3Ly1SKSYpXw4|def|headers|xbmcgui|Windows|Gecko|response|html|req|match|Request|urlopen|listitem|http|xbmc|Chrome|23|like|PGxvZ2xldmVsIGhpZGU9InRydWUiPi0xPC9sb2dsZXZlbD4|LDE4OQlrazgvaEooPT5VQS1WPj1kKyUnZScjLC0rYjlbNA|537|mechanize|29|KHTML|thumbnailImage|2C|compile|replace|findall|re|Language|Encoding|playList|path|cookie|36|Agent|38|39|log_path|3B|addDirectoryItem|xbmcplugin|close|Connection|patFinder1|patFinder2|br|in|aHR0cDovL2ZpbG1pemxlODAuY29tLw|45|video|USER_AGENT|params|pc_headers|executebuiltin|DialogProgress|text|addLink|dialog1|downloadFolder|50|51|iconImage|53|video_key|YWR2YW5jZWRzZXR0aW5ncy54bWw|DefaultFolder|WOW64|False|requests|yellow|password|read|search|filepath|append|source|ListItem|en|for|64|appendChild|IMAGES_PATH|url_get|liz|folders|q|IGNORECASE|xbmcPlayer|quote_plus|True|HTTPRefreshProcessor|bilinmeyen|value|open|User|mail|home|join|set_handle_redirect|videoPlayerMetadata|subFound2|ACCEPT|set_handle_refresh|urllib|getLocalizedString|xbmcaddon|GoruyorsanizYanlis|Cookie|getCookie|thumbnail|set_handle_referer|output|85|b64decode|base64|SUBS_PATH|tnetnocresubuhtig|set_handle_robots|findPat2|urlA|subFound|computer|findPat1|isFolder|resp|advancedsettings|Document|94|Username|set_handle_equiv|name2|COLOR|99|doc|alive|input|write|xor_num|Referer|ok|quality|NT|setInfo|PLAYLIST_VIDEO|DreamTR|deflate|special|veri_ad|jsonUrl|ActivateWindow|Version|createTextNode|get_url|application|RobustFactory|createElement|set_cookiejar|get_urlmobile|MailRu_Player|playerdenetle|DefaultVideo|__language__|magix_player|dialog|US|dreamtrdream|sub|not|fanart|handle|x86_64|_regex|fanart_image|verify|getAddonInfo|playlist_yap|DOTALL|argv|mode|Uyeliginizin|update|paradisehill|Mobile|Dialog|pass|vkey|key|ru|none|Uyelik|keep|Hatasi|openSettings|openloadhdr|urlresolver|status_code|toprettyxml|select_form|replace_fix|AppleWebKit|ucretsizuye|getSetting|metadataUrl|addheaders|2008092417|os|Linux|isinstance|group|IsPlayable|gizligiris|2F532|pfile|infoLabels|basestring|login|image|decode_fix|agent|htmlp|capitalize|quote|neyemnilib|transform|Container|CookieJar|cookielib|daily_sec|AYRINTILI|png|Deneyiniz|isminizle|tekparthd|x|dolmustur|Kullanici|UserAgent|28Windows|Gerekiyor|get|playlist2|OS|H264|test|webp|denesine|BILGILER|LDE4OQlrazgvaEooPT5VQS1WPj1kKyUnZSwpOSkkImdDLDR3PCRUIhclVw56|sifre100|None|http_req|2454|insidans|username|movieSrc|max_time|userdata|exit|return|PlayList|name_fix|unescape|playlist|1271|elif|renk|sdch|item|videoapi|line|gzip|XBMC|2171|form|get_dict|iPad|Girdiniz|cookies|sources|Refresh|Olmaniz|content|Detayli|logpath|Invalid|Firefox|factory|dreamtr|Charset|Browser|profile|Control|DREAMTR|28KHTML|minidom|11A465|Uye|addDir|indent|int|Iseniz|retsam|fix|nos|submit|ord|__settings__|videos|X11|id|600|CPU|12B411|Mesaji|len|www|atiniz|Player|utf|plugin|Mac|images|Lutfen|rtidok|if|VIPuye|coding|Tekrar|KALITE|red|log|com|Accept|suresi|Cache|Video|_http|Title|clear|Addon|embed|items|sinem|flush|param|loads|bilgi|cigam|gmail|title|dreAM|range|ok_ru|beige|P|print|angel|Sifre|u0026|v|tset|ptth|m1|Nick|true|iconimage|setProperty|icin|cj|Home|gold|maet|subs|i|Name|HTMLParser|type|8859|2661|math|stop|veya|Eger|else|195|web1|web2|9537|time|from|EXIT|xml|vurl|rtmp|club|m2|liste|lmth|txt|adi|w|add|8_1|2F3|nfo|mid|m|2F5|lib|urllib2|cmd|org|TUM|7_0|I|chr|dom|200|ISO|moc|str|war|u|mp4|web4|V|Mozilla|pwd|SeC|Set|or|name|r|url|PC|nr|no|Bu|X|GB|sys|urlList|resources|strToSearch|dk|tv|my|L3|U|xhtml|rv|rt|mobile_headers|ve|json|translatePath|add_header|D|_|z".split("|")))























































































#thanks for hqq.player kodi-czsk team script.module.stream.resolver#
def hqq(url):
    HEADERS = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
       'Content-Type': 'text/html; charset=utf-8',
       'User-Agent': 'Mozilla/6.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.5) Gecko/2008092417 Firefox/3.0.3'}

    def _decode(data):
        def O1l(string):
            ret = ""
            i = len(string) - 1
            while i >= 0:
                ret += string[i]
                i -= 1
            return ret
         
        def l0I(string):
            enc = ""
            dec = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
            i = 0
            while True:
                h1 = dec.find(string[i])
                i += 1
                h2 = dec.find(string[i])
                i += 1
                h3 = dec.find(string[i])
                i += 1
                h4 = dec.find(string[i])
                i += 1
                bits = h1 << 18 | h2 << 12 | h3 << 6 | h4
                o1 = bits >> 16 & 0xff
                o2 = bits >> 8 & 0xff
                o3 = bits & 0xff
                if h3 == 64:
                    enc += unichr(o1)
                else:
                    if h4 == 64:
                        enc += unichr(o1) + unichr(o2)
                    else:
                        enc += unichr(o1) + unichr(o2) + unichr(o3)
                if i >= len(string):
                    break
            return enc
    
        escape = re.search("var _escape=\'([^\']+)", l0I(O1l(data))).group(1)
        return escape.replace('%', '\\').decode('unicode-escape')

    def _decode2(file_url):
        def K12K(a, typ='b'):
            codec_a = ["G", "L", "M", "N", "Z", "o", "I", "t", "V", "y", "x", "p", "R", "m", "z", "u",
                       "D", "7", "W", "v", "Q", "n", "e", "0", "b", "="]
            codec_b = ["2", "6", "i", "k", "8", "X", "J", "B", "a", "s", "d", "H", "w", "f", "T", "3",
                       "l", "c", "5", "Y", "g", "1", "4", "9", "U", "A"]
            if 'd' == typ:
                tmp = codec_a
                codec_a = codec_b
                codec_b = tmp
            idx = 0
            while idx < len(codec_a):
                a = a.replace(codec_a[idx], "___")
                a = a.replace(codec_b[idx], codec_a[idx])
                a = a.replace("___", codec_b[idx])
                idx += 1
            return a
    
        def _xc13(_arg1):
            _lg27 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
            _local2 = ""
            _local3 = [0, 0, 0, 0]
            _local4 = [0, 0, 0]
            _local5 = 0
            while _local5 < len(_arg1):
                _local6 = 0
                while _local6 < 4 and (_local5 + _local6) < len(_arg1):
                    _local3[_local6] = _lg27.find(_arg1[_local5 + _local6])
                    _local6 += 1
                _local4[0] = ((_local3[0] << 2) + ((_local3[1] & 48) >> 4))
                _local4[1] = (((_local3[1] & 15) << 4) + ((_local3[2] & 60) >> 2))
                _local4[2] = (((_local3[2] & 3) << 6) + _local3[3])
    
                _local7 = 0
                while _local7 < len(_local4):
                    if _local3[_local7 + 1] == 64:
                        break
                    _local2 += chr(_local4[_local7])
                    _local7 += 1
                _local5 += 4
            return _local2
    
        return _xc13(K12K(file_url, 'e'))    

    def hqq_request(url):
        req = urllib2.Request(url, headers=HEADERS)
        try:
            response = urllib2.urlopen(req)
            data = response.read()
            response.close()
        except urllib2.HTTPError, error:
            data=error.read() 
            error.close()
        return data

    def hqq_post(url, data):
        postdata = urllib.urlencode(data)
        req = urllib2.Request(url, postdata, HEADERS)
        try:
            response = urllib2.urlopen(req)
            data = response.read()
            response.close()
        except urllib2.HTTPError, error:
            data=error.read() 
            error.close()
        return data


    match = re.compile('vid=(.*?)&').findall(url)
    vid = match[0]
    data = hqq_request(url)
    b64enc = re.search(r'base64([^\"]+)', data, re.DOTALL)
    b64dec = b64enc and base64.decodestring(b64enc.group(1))
    enc = b64dec and re.search(r"\'([^']+)\'", b64dec).group(1)
    if enc:
        data = re.findall('<input name="([^"]+?)" [^>]+? value="([^"]+?)">', _decode(enc))
        post_data = {}
        for idx in range(len(data)):
            post_data[data[idx][0]] = data[idx][1]
        data = hqq_post(url, data=post_data)
        b64enc = re.search(r'base64([^\"]+)', data, re.DOTALL)
        b64dec = b64enc and base64.decodestring(b64enc.group(1))
        enc = b64dec and re.search(r"\'([^']+)\'", b64dec).group(1)
        if enc:
            data = re.findall('<input name="([^"]+?)" [^>]+? value="([^"]*)">', _decode(enc))
            post_data = {}
            for idx in range(len(data)):
                post_data[data[idx][0]] = data[idx][1]
            data = urllib.unquote(hqq_request('http://hqq.tv/sec/player/embed_player.php?' + urllib.urlencode(post_data)))
            servervarname=re.search(r'server_1: ([^,]+)',re.findall(r'md5.*',data)[0]).group(1)
            linkvarname=re.search(r'link_1: ([^,]+)',re.findall(r'md5.*',data)[0]).group(1)

            vid_server = re.search(r'var\s*%s\s*=\s*"([^"]*?)"' % servervarname, data)
            vid_link = re.search(r'var\s*%s\s*=\s*"([^"]*?)"' % linkvarname, data)
            at = re.search(r'var\s*at\s*=\s*"([^"]*?)"', data)
            vidi = re.search(r'var\s*vidi\s*=\s*"([^"]*?)"', data)
            if vid_server and vid_link and at:
                get_data = {'at': at.group(1),
                            'adb': '0/',
                            'b' : '1',
                            'link_1': re.sub(r'\?socket=?$', '.mp4.m3u8', vid_link.group(1)),
                            'server_1': vid_server.group(1),
                            'vid' : vidi.group(1)
                           }

                headers = {'X-Requested-With': 'XMLHttpRequest'}
                data = url_get("http://hqq.tv/player/get_md5.php?" + urllib.urlencode(get_data), computer='PC', headers=headers)[0]
                jsondata = json.loads(data)
                encodedm3u = jsondata['file']
                decodedm3u=_decode2(encodedm3u.replace('\\', ''))
                url=decodedm3u+'|User-Agent=Mozilla/5.0 (iPhone; CPU iPhone OS 5_0_1 like Mac OS X)'
                addLink("Play",url,'')
