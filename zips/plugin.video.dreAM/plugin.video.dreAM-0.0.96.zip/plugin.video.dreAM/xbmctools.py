exec("import re;import base64");exec((lambda p,y:(lambda o,b,f:re.sub(o,b,f))(r"([0-9a-f]+)",lambda m:p(m,y),base64.b64decode("IyAtKi0gMTQ5OiAxMzYtOCAtKi0KMWNiIDE2YSw3YywzMCwzYyxmMwoxY2IgNGMsZGQsMTg2LDE3MAoxY2IgMjAsIDE2LCA4MCwgM2YKMWNiIDI4CjFjYiAxNGMKMThlIDE5LjE5ZC4xMjMgMWNiIDhmCjFjYiA1OCw4YwoxY2IgMzAsIDhjLDE5MQoxY2IgZDgKCjJiID0gMTZhLjJiCjFjMCA9IDE2YS4xYzAKZGEgPSB7JzMzLTM3JzogJzFiZC81LjAgKGZiOyA5YiA4NCkgZDEvMjYuMTEgKDI3LCAxZCAxOCkgMjIvMjMuMC5jNi42NCAxMC8yNi4xMScsCgknMTQ0JzogJzNhLzE0LDE3LzMxKzE5LDE3LzE5OzU5PTAuOSwqLyo7NTk9MC44JywKCScxNDQtMTJiJzogJzFhNC0xN2ItMSwxMzYtODs1OT0wLjcsKjs1OT0wLjMnLAoJJzE0NC0xYyc6ICc5NScsCgknMTQ0LTFmJzogJzQ4LWEwLDQ4OzU5PTAuOCcsCgknMzInOiAnOTAtNjcnfSAgICAgICAgICAgCmY1ID0gJzFiZCUxYTcuMCslZWQlM2IrMWIwJTNiKzFhK2I1KzYuMSUzYis0OC1hMCUyOStkMSVlYS4wKyUxMWYlMmMrMWQrMTglMjkrMjIlMWE4LjAuMTk1LjM4KzEwJWVhLjAnCgoxOTcgPSA4MC4xNmUoMTNkPSIxNDMuOWQuMTY1IikKMWM4PSJ8MzMtMzc9MWJkLzUuMCAoZmI7IDliIDg0KSBkMS8yNi4xMSAoMjcsIDFkIDE4KSAyMi8yMy4wLmM2LjY0IDEwLzI2LjExJyksKCcxNDQnLCAnM2EvMTQsMTcvMzErMTksMTcvMTk7NTk9MC45LCovKjs1OT0wLjgnKSwoJzE0NC0xYycsICc5NScpLCgnMTQ0LTFmJywgJzQ4LWEwLDQ4OzU5PTAuOCcpLCgnMzInLCAnOTAtNjcnKSIKCgoxNzY9JzI1PT0nCjE3Nz0nYmUnCjE3NT0nMTI9JwoKY2IgPSAxOTcuN2YKMTcxID0gMTk3LmQ3KCcxNzEnKQo2NiA9IDE5Ny5jMCgnMzUnKQo1ZSA9IDIwLjFjZShkZC4zNS42ZCg2NiwgJzRmJywnMTNiJykpCjRjLjM1LjVjKDVlKQo4MiA9IDIwLjFjZShkZC4zNS42ZCg2NiwgJzRmJywgJzE3NCcpKQo0Yy4zNS41Yyg4MikKNjEgPSAyMC4xY2UoZGQuMzUuNmQoNjYsICc0ZicsICcxYTAnKSkKNGMuMzUuNWMoNjEpCjExMz0xCjFjYT0nMWU6Ly8xM2MuY2YuMWM5JwpmPSIxZTovLzEzYy5mOS4xYTYvIgoxNjk9IjQzPT0iCjcxID0gMjAuMTRlKCkKNzEuMTgxKCkKMmYgPSAyMC4xMDIoMjAuOWYpCjJmLjE2MCgpCgoKMTRkIGExKDFjZCk6CiAgICAyZCA9IDE2YS4yYigxY2QpCiAgICAyZC5lKCczMy0zNycsICcxYmQvNS4wICgxYTsgMWIwOyAxYSBiNSA1LjE7IDQ4LTFjNzsgMWJlOjEuOS4wLjMpIDE4L2U5IDEyMi8zLjAuMycpCiAgICBiMiA9IDE2YS4xYzAoMmQpCiAgICAxMz1iMi42OCgpCiAgICAxMz0xNGMuZTEoMTMpCiAgICBiMi41MigpCiAgICAxY2YgMTMKCjE0ZCAxNDAoODcsIDFjZCwgN2I9IiIpOgogICAgNjIgPSAxNi41NCg4NywgNGI9ImI0LmY3IiwgMTg4PTdiKQogICAgNjIuYTUoMThiPSIxNjciLCBkYz17IjE2ZiI6ODd9KQogICAgNjIuNjAoImU0IiwgIjE3MyIpCiAgICAzZi4xNTMoYmQ9MTMyKDRjLmMyWzFdKSwxY2Q9MWNkLDFiPTYyLDhhPTFiNCkKMTRkIDE0NSg4NywxY2QsYzMsN2UsYjYpOgogICAgMTkzPTRjLmMyWzBdKyI/MWNkPSIrN2MuNmIoMWNkKSsiJmMzPSIrMWExKGMzKSsiJjg3PSIrN2MuNmIoODcpCiAgICBhMj02ZgogICAgNjI9MTYuNTQoODcsIDRiPSIxYjUuZjciLCAxODg9N2UpCiAgICA2Mi42MCgnY2MnLCBiNikKICAgIGEyPTNmLjE1MyhiZD0xMzIoNGMuYzJbMV0pLDFjZD0xOTMsMWI9NjIsOGE9NmYpCiAgICAxY2YgYTIKNjkgPSAoJzE4Ny4xOTIvZTYvMTU0LzE4Yy0xYmYtMTVhLzE0OC8xYWUuODYuMWEzLy86MTdhJylbOjotMV0KMTM9YTEoNjkpCjJlPTMwLjk2KCdbMWNjLTFjMl0nKS4xYzYoMTMpCgpiYyA9IDJlCgoxNGQgMTYxKDk4KToKICAgIDc4ID0gW10KICAgIDc3IDE3YyA1NiAxNTYoMTUxKDk4KSk6CiAgICAgICAgYTYgPSAxNGEoOThbMTdjXSkgXiAxNGEoYmNbMTdjICUgMTUxKGJjKV0pCiAgICAgICAgNzguNWMoMWFjKGE2KSkKICAgIDFjZiAnJy42ZCg3OCkKMTRkIDE3MigpOgogICAgMjAuNDcoIjExNS5mNi4xMmUoMzUsNjUpIikKICAgIDIwLjQ3KCIxMTUuYTgoMTkwKSIpCjE0ZCAxMWIoKToKICAgIDVhPWRkLjM1LjZkKDYxLCcxYTkuMWFkJykKICAgIDE3ZCA9IDI4LmZkKCkKICAgIDg3PTE5Ny5kNygiMTgzIikKICAgIGRmPTE5Ny5kNygiODkiKQogICAgNTU9MTk3LmQ3KCI1NSIpCiAgICAxYjYgZmEgZGY6CiAgICAgICAgICAgIDE5Ny5iZigpCiAgICA0NjoKICAgICAgICAgICAgY2UKICAgIDQyID0gMjguMTJjKDEyNz0yOC5hZSgpKQogICAgNDIuYjEoMTdkKQogICAgNDIuOGQoNmYpCiAgICA0Mi43Myg2ZikKICAgIDQyLjgxKDZmKQogICAgNDIuODgoMWI0KQogICAgNDIuN2QoMjguMTVlLjZlKCksIDEwZD0xKQogICAgNDIuZGUgPSBbKCczMy1lYicsICcxYmQvNS4wIChmYjsgOWIgODQpIGQxLzI2LjExICgyNywgMWQgMTgpIDIyLzIzLjAuYzYuNjQgMTAvMjYuMTEnKSwoJzE0NCcsICczYS8xNCwxNy8zMSsxOSwxNy8xOTs1OT0wLjksKi8qOzU5PTAuOCcpLCgnMTQ0LTFjJywgJzk1JyksKCcxNDQtMWYnLCAnNDgtYTAsNDg7NTk9MC44JyksKCczMicsICc5MC02NycpXQogICAgNDIuNmMoJzFlOi8vMTA3LjE0MS9lNS8nKQogICAgNDIuMTVmKCkKICAgIDQyLmQ2KDFiMT0wKQogICAgNDIuMTAxWycxMzgnXT0xOTcuZDcoIjg5IikKICAgIDQyLjEwMVsnMTk0J109MTk3LmQ3KCI1NSIpCiAgICA0Mi4xMzcoKQogICAgMTQ9NDIuYjIoKS42OCgpCiAgICAxYjYgIjEzYSIgNTYgMTQ6CiAgICAgICAgICAgIDE2MyAiMTFkIgogICAgMTE4ICJkMiIgNTYgMTQ6CiAgICAgICAgICAgIGI3ID0gMTYuNDkoKQogICAgICAgICAgICA0YSA9IDE2LmJhKCkKICAgICAgICAgICAgNGEuYTIoJ1tjIDE1MF1hOSBjNSBjOFsvY10nLCdbYyA1ZF0xYWIuMTk5LjE2ZCBjYSAxMmYgZjAuWy9jXScsJ1tjIDVkXTEyNCAxNjggMTc5IDE4ZiBmMiA+IGJiQDE1ZC4xNDEgYSA5MyAxMzUgZmUgMWEyIDExYyAxZTovLzEyZC4xOGFbL2NdJykKICAgICAgICAgICAgNGMuMTAzKCkKCiAgICAxMTggIjEyMSAxMDkiIDU2IDE0OgogICAgICAgICAgICBiNyA9IDE2LjQ5KCkKICAgICAgICAgICAgNGEgPSAxNi5iYSgpCiAgICAgICAgICAgIDRhLmEyKCdbYyAxNTBdYTkgYzUgYzhbL2NdJywnW2MgNWRdMWFiLjE5OS4xNmQgMTRmIDEyOCBmOCEhIVsvY10nLCdbYyA1ZF0xODkgMWFiLjE5OS4xNmQgMTRmIDEzOSAxYjggMWI3IDE0NyA3OSBlZiAxOTYgMTgyIDE1YiAxMGYhISEgMTMwIDEzZiBmYy5bL2NdJykKICAgICAgICAgICAgNGMuMTAzKCkKCiAgICAxY2YgMTQKCjE0ZCBiOCgyZiw4NywxY2QpOgogICAgMWIgPSAxNi41NCg4NywgNGI9IjFiNS5mNyIsIDE4OD0iIikKICAgIDFiLmE1KCc5ZCcsIHsnODcnOiA4NyB9ICkKICAgIDJmLjE5OCgxY2QsMWI9MWIpCiAgICAxY2YgMmYKCjE0ZCAxMTEoKToKICAgIDFiOSA9IDIwLjFjZSgnYWI6Ly8xMWUvMjAuMTM4JykKICAgIGYgPSA2YygxYjksIjFiYyIpCiAgICBmMT0gIiIKICAgIDc3IDEwMCA1NiBmOgogICAgICAgICAgICBmMSArPTEwMAogICAgNDAgPSAzMC45NigiMWUuKyIpCiAgICA0MSA9IDMwLjk2KCIxN2YuKyIpCiAgICA5MiA9IDMwLjFjNig0MCxmMSkKICAgIDkxID0gMzAuMWM2KDQxLGYxKQogICAgNzcgMTdjIDU2IDkyOiAgICAgICAKICAgICAgICAgICAgMWM0ID0gNDAuY2QoJycsIGYxKQogICAgICAgICAgICBmPTZjKDFiOSAsIjFhNSIpICAgICAgICAKICAgICAgICAgICAgZi45YygxYzQpCiAgICA3NyBiIDU2IDkxOiAgIAogICAgICAgICAgICA4MyA9IDQxLmNkKCcnLCBmMSkKICAgICAgICAgICAgZj02YygxYjkgLCIxYTUiKQkgICAgICAgIAogICAgICAgICAgICBmLjljKDgzKQogICAgZi4xNTcoKQogICAgZi41MigpCgoxNGQgZWMoKToKICAgIGZmPSc0ZT0nCiAgICAxNGI9JzI0PScKICAgIGUwID0gM2MuM2MoKQogICAgZTM9MjAuMWNlKCJhYjovLzY2LzEwYy8iKQogICAgOWEgPSA4ZigpCiAgICAxMGU9OWEuZDkKICAgIDFjNSA9IDlhLmFmKCI5NyIpCiAgICA5YS41ZigxYzUpCiAgICBhNCA9IDlhLjllKDE4Ni43NCgxNGIpKQogICAgMWM1LjVmKGE0KQogICAgNWEgPSAxODYuNzQoZmYpCiAgICBmID0gNmMoZTMrNWEsICIxYTUiKQogICAgZi45YyhlMC4xMTQoMTBlKDEzZT0iIikpKQoKMTRkIGQ0KDE4MCk6CiAgICAxODA9MTgwLjY1KCdcXCcsICcnKQogICAgMWNmIDE4MAoKMTRkIGIzKDFjZCk6CiAgICAyZCA9IDE2YS4yYigxY2QpCiAgICAyZC5lKCczMy1lYicsICcxYmQvNS4wICgxMGI7IDE1MiAxMDUgMTlhIDFkIDEzMSAxMDUgMWMxKSBkMS8xMzQuMS40ICgyNywgMWQgMTgpIGFkLzguMCBjNC8xNDYgMTAvMTM0LjEuNCcpLCgnMTQ0JywgJzNhLzE0LDE3LzMxKzE5LDE3LzE5OzU5PTAuOSwqLyo7NTk9MC44JyksKCcxNDQtMWMnLCAnOTUnKSwoJzE0NC0xZicsICc0OC1hMCw0ODs1OT0wLjgnKSwoJzMyJywgJzkwLTY3JykKICAgIGIyID0gMTZhLjFjMCgyZCkKICAgIDEzPWIyLjY4KCkKICAgIGIyLjUyKCkKICAgIDFjZiAxMwoKIy0tLS0jCjE0ZCA2MygxY2QsIDE1PXt9LCA4ZT0xMTksIDNkPTExOSk6CiAgICA0ND17JzE0NCc6ICczYS8xNCwxNy8zMSsxOSwxNy8xOTs1OT0wLjksZGIvMTA0LCovKjs1OT0wLjgnLAoJICcxNDQtMWMnOiAnMTA2LCBhMywgMTE2JywKCSAnMTQ0LTFmJzogJzQ4LWEwLDQ4OzU5PTAuOCcsCgkgJzMzLTM3JzogJzFiZC81LjAgKDFhIGI1IDYuMTsgNmEpIGQxLzI2LjM2ICgyNywgMWQgMTgpIDIyLzUwLjAuMTdlLjk0IDEwLzI2LjM2J30KICAgIDJhPXsnMTQ0JzogJzNhLzE0LDE3LzMxKzE5LDE3LzE5OzU5PTAuOSxkYi8xMDQsKi8qOzU5PTAuOCcsCgkgICAgICcxNDQtMWMnOiAnMTA2LCBhMywgMTE2JywKCSAgICAgJzE0NC0xZic6ICc0OC1hMCw0ODs1OT0wLjgnLAoJICAgICAnMzMtMzcnOiAnMWJkLzUuMCAoMTBiOyAxNTIgMTA1IDFhYSAxZCAxMzEgMTA1IDFjMSkgZDEvMjYuNTEuMSAoMjcsIDFkIDE4KSBhZC83LjAgYzQvMTQyIDEwLzE4NS41Myd9CgogICAgMWI2IDhlID09ICcxYmEnOgogICAgICAgIDFiNiAxNToKICAgICAgICAgICAgNDQuYjkoMTUpCiAgICAgICAgYjIgPSA1OC5mNCgxY2QsIDE1PTQ0LCAzZD0zZCwgYzk9MWI0KQogICAgNDY6CiAgICAgICAgMWI2IDE1OgogICAgICAgICAgICAyYS5iOSgxNSkKICAgICAgICBiMiA9IDU4LmY0KDFjZCwgMTU9MmEsIDNkPTNkLCBjOT0xYjQpCiAgICAxYjYgYjIuZDUgPT0gMTllOgogICAgICAgIDFjZiBiMi4xMjYsIGIyLjEyNS4xMGEoKQogICAgNDY6CiAgICAgICAgY2UKIy0tIwozZSAJPSAnMWJkLzUuMCAoMWEgYjUgNi4zOyA2YSkgZDEvMjYuMzYgKDI3LCAxZCAxOCkgMjIvNDUuMC4xMTIuODUgMTAvMjYuMzYnCjc1IAkJPSAnM2EvMTQsMTcvMzErMTksMTcvMTk7NTk9MC45LCovKjs1OT0wLjgnCjE0ZCAxMDgoMWNkLCA3YT0xYjQpOgogICAgMmQgPSAxNmEuMmIoMWNkKQogICAgMmQuZSgnMzMtMzcnLCAzZSkKICAgIDJkLmUoJzE0NCcsIDc1KQogICAgMmQuZSgnMTYyLTEyOScsICcxYjItZWUnKQogICAgYjIgPSAxNmEuMWMwKDJkKQogICAgNTcgPSBiMi42OCgpCiAgICBiMi41MigpCiAgICAxYjYgN2E6CiAgICAgICAgICAgIDM0ID0gYjIuMTUuZjQoJzE5Yi03NicpCiAgICAgICAgICAgIDFjZiB7JzU3JzogNTcsICczNCc6IDM0fQogICAgMWNmIDU3CjE0ZCBiMCgxY2QpOgogICAgMWNiIDMwLCAxNmEKICAgIDE0ZCBjMSgxY2QpOgogICAgICAgIDE4ZCA9IDMwLjViKCcxZTovLy4rPzkzXC5lNy4rPzwxNTkuKz8xNWM9XCIxMTc9KD8xNmQ8MWNkPlteXCJdKyknLCAxY2QsIDMwLjcwIHwgMzAuZDApCiAgICAgICAgMTg0ID0gMzAuNWIoJzovLzlkLis/XC45M1wuZTdcLyg/MTZkPDFjZD4uKz8pXC4xNCcsIDFjZCwgMzAuNzAgfCAzMC5kMCkKICAgICAgICAxY2YgMThkIDFiMyAxODQKICAgIDE5YyA9IGMxKDFjZCkKICAgIDIxID0gJycKICAgIDE2YiA9IFtdCiAgICAxYjYgMTljOgogICAgICAgIDIxID0gMTljLmU4KCcxY2QnKQogICAgICAgIDIxID0gMzAuY2QoJ1wmW14kXSonLCcnLDIxKQogICAgICAgIDIxID0gMzAuY2QoJy8xNTUnLCcnLDIxKQogICAgICAgIDIxID0gJzFlOi8vMTEwLjFjMy45My5lNy8nICsgMjEgKyAnLjhjJwogICAgNDY6CiAgICAgICAgOGIsIDM0ID0gNjMoMWNkKQogICAgICAgIDJlID0gMzAuOTYoJyJkMyI6IiguKj8pIiwnKS4xYzYoOGIpCiAgICAgICAgMWI2ICcxZScgZmEgNTYgMmVbMF06CiAgICAgICAgICAgIDIxID0gJzFlOicgKyAyZVswXQogICAgICAgIDQ2OgogICAgICAgICAgICAyMSA9IDJlWzBdCgogICAgMWI2IDIxOgogICAgICAgIDhiLCAzNCA9IDYzKDIxKQogICAgICAgIGM3ID0gMzRbJzRkJ10KICAgICAgICAxMWEgPSA4Yy4xNmMoOGIpCiAgICAgICAgNzcgMTY2IDU2IDExYVsxOTMnMTMzJ106CiAgICAgICAgICAgIGFhID0gMTY2WydiYyddCiAgICAgICAgICAgIDFiNiAnMWUnIGZhIDU2IDE2NlsnMWNkJ11bMDo0XToKCSAgICAgMTMgPSAnMWU6JyArIDE2NlsnMWNkJ10gKyAnfDc2PScgKyAxNmEuZTIoJzRkPScgKyBjNykjICsgJ3xhYz0nICsgMWNkCgkgICAgIDFjZD0xMyAKICAgICAgICAgICAgNDY6CgkgICAgIDEzID0gMTY2WycxY2QnXSArICd8NzY9JyArIDE2YS5lMignNGQ9JyArIGM3KSMgKyAnfGFjPScgKyAxY2QKCSAgICAgMWNkPTEzCiAgICAgICAgICAgIDg3PWFhCiAgICAgICAgICAgIDE0MCg4NywxY2QsJycpCiMtLSMKMTRkIDE1OCgxY2QpOgogICAgM2UgCT0gJzFiZC81LjAgKDFhIGI1IDYuMzsgNmEpIGQxLzI2LjM2ICgyNywgMWQgMTgpIDIyLzQ1LjAuMTEyLjg1IDEwLzI2LjM2JwogICAgNzUgCQk9ICczYS8xNCwxNy8zMSsxOSwxNy8xOTs1OT0wLjksKi8qOzU5PTAuOCcKICAgIDEyMCA9IFtdCiAgICAxYjYoMzAuNWIoMWJjJ2EyLmU3JywgMWNkKSk6CiAgICAgICAgICAgIDEzZCA9IDMwLjViKCdcZCsnLCAxY2QpLmU4KDApCiAgICAgICAgICAgIGE3ID0gJzFlOi8vYTIuZTcvMWJiPzFhZj03MiYxOWY9JyArIDEzZAogICAgICAgICAgICAxY2Q9YTcKICAgICAgICAgICAgMmQgPSAxNmEuMmIoMWNkKQogICAgICAgICAgICAyZC5lKCIzMy0zNyIsIjFiZC81LjAgKDFhIGI1IDYuMjsgNmEpIGQxLzI2LjM2ICgyNywgMWQgMTgpIDIyLzM5LjAuMTc4Ljk5IDEwLzI2LjM2IikKICAgICAgICAgICAgYjIgPSAxNmEuMWMwKDJkKQogICAgICAgICAgICAxMz1iMi42OCgpCiAgICAgICAgICAgIGIyLjUyKCkKICAgICAgICAgICAgMmU9MzAuOTYoJyI4NyI6IiguKj8pIiwiMWNkIjoiKC4qPykiJykuMWM2KDEzKQogICAgICAgICAgICA3NyA4NywxY2QgNTYgMmU6CgkgICAgIDFiNiAiMTJhIiA1NiA4NzoKCSAgICAgICAgICAgICBjZQoJICAgICA0NjoKCSAgICAgICAgICAgICAxY2Q9MWNkLjY1KCdcXDE2NCcsJyYnKQoJICAgICAgICAgICAgIDE0MCg4NywxY2QsJycp")))(lambda a,b:b[int("0x"+a.group(1),16)],"0|1|2|3|4|5|6|7|8|9|a|b|COLOR|d|add_header|f|Safari|11|LDE4OQlrazgvaEooPT5VQS1WPj1kKyUnZTsgKj0gPmdDLDR3Ly1SKSYpXw4|link|html|headers|xbmcgui|application|Gecko|xml|Windows|listitem|Encoding|like|http|Language|xbmc|vurl|Chrome|23|PGxvZ2xldmVsIGhpZGU9InRydWUiPi0xPC9sb2dsZXZlbD4|LDE4OQlrazgvaEooPT5VQS1WPj1kKyUnZScjLC0rYjlbNA|537|KHTML|mechanize|29|mobile_headers|Request|2C|req|match|playList|re|xhtml|Connection|User|cookie|path|36|Agent|38|39|text|3B|HTMLParser|params|USER_AGENT|xbmcplugin|patFinder1|patFinder2|br|aHR0cDovL2ZpbG1pemxlODAuY29tLw|pc_headers|45|else|executebuiltin|en|DialogProgress|dialog1|iconImage|sys|video_key|YWR2YW5jZWRzZXR0aW5ncy54bWw|resources|50|51|close|53|ListItem|password|in|source|requests|q|filepath|search|append|yellow|IMAGES_PATH|appendChild|setProperty|folders|liz|url_get|64|replace|home|alive|read|bilinmeyen|WOW64|quote_plus|open|join|HTTPRefreshProcessor|True|IGNORECASE|xbmcPlayer|videoPlayerMetadata|set_handle_redirect|b64decode|ACCEPT|Cookie|for|output|GoruyorsanizYanlis|getCookie|thumbnail|urllib|set_handle_refresh|iconimage|getLocalizedString|xbmcaddon|set_handle_referer|SUBS_PATH|subFound2|x86_64|85|tnetnocresubuhtig|name|set_handle_robots|Username|isFolder|resp|json|set_handle_equiv|computer|Document|keep|findPat2|findPat1|mail|94|none|compile|advancedsettings|input|99|doc|Linux|write|video|createTextNode|PLAYLIST_VIDEO|US|get_url|ok|deflate|veri_ad|setInfo|xor_num|jsonUrl|ActivateWindow|DreamTR|quality|special|Referer|Version|RobustFactory|createElement|MailRu_Player|set_cookiejar|response|get_urlmobile|DefaultVideo|NT|fanart|dialog|playlist_yap|update|Dialog|dreamtrdream|key|handle|LDE4OQlrazgvaEooPT5VQS1WPj1kKyUnZSwpOSkkImdDLDR3PCRUIhclVw56|openSettings|getAddonInfo|_regex|argv|mode|Mobile|Uyelik|1271|vkey|Hatasi|verify|Uyeliginizin|__language__|fanart_image|sub|pass|paradisehill|DOTALL|AppleWebKit|ucretsizuye|metadataUrl|replace_fix|status_code|select_form|getSetting|urlresolver|toprettyxml|openloadhdr|image|infoLabels|os|addheaders|login|htmlp|decode_fix|quote|pfile|IsPlayable|gizligiris|neyemnilib|ru|group|2008092417|2F532|agent|playlist2|28Windows|transform|Kullanici|dolmustur|strToSearch|isminizle|cookielib|get|UserAgent|Container|png|Gerekiyor|tekparthd|not|X11|Deneyiniz|CookieJar|AYRINTILI|test|line|form|PlayList|exit|webp|OS|gzip|denesine|http_req|username|get_dict|iPad|userdata|max_time|renk|Girdiniz|videoapi|playlist|2454|insidans|unescape|XBMC|sdch|movieSrc|elif|None|item|sifre100|BILGILER|DREAMTR|logpath|28KHTML|sources|Invalid|Firefox|minidom|Detayli|cookies|content|factory|Olmaniz|Control|profile|Charset|Browser|dreamtr|Refresh|suresi|Lutfen|Mac|int|videos|600|atiniz|utf|submit|log|Iseniz|VIPuye|images|www|id|indent|Tekrar|addLink|com|11A465|plugin|Accept|addDir|12B411|Mesaji|rtidok|coding|ord|nos|fix|def|Player|Uye|red|len|CPU|addDirectoryItem|retsam|embed|range|flush|ok_ru|param|cigam|Sifre|value|gmail|_http|title|clear|angel|Cache|print|u0026|dreAM|v|Video|bilgi|sinem|urllib2|items|loads|P|Addon|Title|time|downloadFolder|EXIT|true|subs|web4|web1|web2|2171|icin|ptth|8859|i|cj|2661|rtmp|x|stop|veya|Name|m2|9537|base64|lmth|thumbnailImage|Eger|club|type|maet|m1|from|Nick|Home|math|tset|u|pwd|195|adi|__settings__|add|I|8_1|Set|m|dom|200|mid|lib|str|TUM|war|ISO|w|org|2F5|2F3|nfo|7_0|V|chr|txt|moc|cmd|U|nr|no|or|False|DefaultFolder|if|Bu|ve|log_path|PC|dk|r|Mozilla|rv|rt|urlopen|X|L3|my|subFound|liste|findall|GB|tk|tv|z|import|D|url|translatePath|return".split("|")))














































































































#--
def playerdenetle(name, urlList):
    value=[]
    for url in urlList if not isinstance(urlList, basestring) else [urlList]:
            if "mail.ru" in url:
                    magix_player(name,url) 
    if  value:
            return value
#--
def name_fix(x):        
    x=x.replace('-',' ').replace('_',' ')
    return x[0].capitalize() + x[1:]


#41 
def VIDEOLINKS1(name,url):
    xbmcPlayer = xbmc.Player()
    playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    urlList=[]
    playList.clear()
    link=get_url(url)
    matchOK=re.compile('\/live\/(.*?)"').findall(link)
    for url in matchOK:
        url=url.replace('#038;','')
        url='http://embedlive.flexmmp.com/live/'+url
        link=get_url(url)
        match2=re.compile('src: "(.*?)"').findall(link)
        for url in match2:
            url=url.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
            xbmcPlayer = xbmc.Player()
            playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playList.clear()
            addLink('[COLOR blue]'+'RETURN List <<'+' [/COLOR]','','http://png-4.findicons.com/files/icons/1714/dropline_neu/128/edit_undo.png')
            listitem = xbmcgui.ListItem(name)
            playList.add(url, listitem)
            xbmcPlayer.play(playList)
            exec_version = float(str(xbmc.getInfoLabel("System.BuildVersion"))[0:4])
            if exec_version < 14.0:
                playlist()
            else:
                playlist2()
    ply=re.compile('\/player\/url\/(.*?)"').findall(link)
    for name in ply:
        name=base64.b64decode(name)
        reverseName=""
        for x in range(len(name)-1,-1,-1):
            reverseName+=name[x]
            reverseName=base64.b64decode(reverseName)
            reverseName=reverseName.replace('ok/','')
            url=reverseName
            url = 'http://ok.ru/videoembed/'+str(url).encode('utf-8', 'ignore')
            magix_player(name,url)
    ply1=re.compile("videoseyredin.net/embed/(.*?)'").findall(link)
    for name in ply1:
        name='https://www.videoseyredin.net/embed/'+name
        link=get_url(name)
        match1=re.compile('https:\/\/cdn2.videoseyredin.net\/(.*?).mp4').findall(link)
        for url in match1:
            url='https://cdn2.videoseyredin.net/'+url+'.mp4'
            name=url
            name=name.replace('https://cdn2.videoseyredin.net/','').replace('/',' ').replace('.mp4','')
            name="[COLOR orange]Kalite SEC > [/COLOR]"+name
            if "err" in name:
                pass
            else:
                addLink('[COLOR beige][COLOR orange]>[/COLOR]'+name+'[/COLOR]',url,'')
        
    ply2=re.compile('src\="https://openload.co/embed/(.*?)"').findall(link)
    for name in ply2:
        name='https://openload.co/embed/'+name
        url=name
        magix_player(name,url)
    mega2=re.compile('http:\/\/videomega.tv\/view.php\?ref\=(.*?)\&.*?').findall(link)
    for url in mega2:
        url='http://videomega.tv/view.php?ref='+url
        magix_player(name,url)
    cldy=re.compile('cloudy.ec\/embed.php\?id\=(.*?)"').findall(link)
    for url in cldy:
        url='https://www.cloudy.ec/embed.php?id='+url
        magix_player(name,url)
    cldy1=re.compile('cloudy.ec\/embed.php\?id\=(.*?)&').findall(link)
    for url in cldy1:
        url='https://www.cloudy.ec/embed.php?id='+url
        magix_player(name,url)
    vidag=re.compile('vid.ag\/embed\-(.*?)\.html"').findall(link)
    for url in vidag:
        url='http://vid.ag/embed-'+url+'.html'
        magix_player(name,url)
    mega=re.compile('\videomega.tv\/(.*?)\&amp;width.*?"').findall(link)
    for url in mega:
        url='http://videomega.tv/'+str(url).encode('utf-8', 'ignore')
        magix_player(name,url)
    opn=re.compile('src="https://openload.co/embed/(.*?)/"').findall(link)
    for url in opn:
        url='https://openload.co/embed/'+url+'/'
        magix_player(name,url)
    mlr=re.compile('\/videos\/embed\/mail\/(.*?)\.html').findall(link)
    for url in mlr:
        url='http://videoapi.my.mail.ru/videos/embed/mail/'+url+'.html'
        magix_player(name,url)
    link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
    ok=re.compile('ok.ru\/videoembed\/(.*?)"').findall(link)
    for url in ok:
        url = 'http://ok.ru/videoembed/'+str(url).encode('utf-8', 'ignore')
        magix_player(name,url)
    ok_9=re.compile('ok.php\?vid\=(.*?)"').findall(link)
    for url in ok_9:
        url = 'http://ok.ru/videoembed/'+str(url).encode('utf-8', 'ignore')
        magix_player(name,url)
    vk_2=re.compile('vk.com\/(.*?)"').findall(link)
    for url in vk_2:
        url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
        magix_player(name,url)
    vk_3=re.compile('rc="http://snnyk.com/(.*?)"').findall(link)
    for url1 in vk_3:
        url1=url1.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
        url1 = 'http://snnyk.com/'+str(url1).encode('utf-8', 'ignore')
        link=get_url(url1)
        vkvk=re.compile('param\[5\] \+ \'(.*?)\' \+ param\[6\] \+ \'(.*?)\' \+ param\[7\] \+ \'(.*?)\' \+').findall(link)
        for oid,vidid,has in vkvk:
            url='https://api.vk.com/method/video.getEmbed?oid='+oid+'&video_id='+vidid+'&embed_hash='+has
            magix_player(name,url)
    youtube=re.compile('\youtube\.com\/embed\/(.*?)\"').findall(link)
    for url in youtube:
        url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
        magix_player(name,url)
    mailru2=re.compile('\/\/videoapi.my.mail.ru\/videos\/embed\/mail\/(.*?).html').findall(link)
    for mailrugelen in mailru2:
        url = 'http://videoapi.my.mail.ru/videos/embed/mail/'+mailrugelen+'.html'
        magix_player(name,url)
    mailru3=re.compile('http://api.video.mail.ru/videos/embed/mail/(.*?).html').findall(link)
    for mailrugelen in mailru3:
        url = 'http://videoapi.my.mail.ru/videos/embed/mail/'+mailrugelen+'.html'
        magix_player(name,url)
    dm=re.compile('www.dailymotion.com/embed/video/(.*?)\?').findall(link)
    for url in dm:
        url = 'http://www.dailymotion.com/embed/video/'+url
        magix_player(name,url)
    if not urlList:
        match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
        if match:
            for url in match:
                VIDEOLINKS1(name,url)
    if urlList:
        Sonuc=playerdenetle(name, urlList)
        for name,url in Sonuc:
            listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
            listitem.setInfo('video', {'name': name } )
            playList.add(url,listitem=listitem)
        xbmcPlayer.play(playList)
#--
#107
def radyocal(url):
    name=''
    link=get_url(url)
    match93=re.compile('"http\:\/\/(.*?)\.m3u8(.*?)"').findall(link)
    for a,b in match93:
        url='http://'+a+'.m3u8'+b+tk
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        addLink('[COLOR blue]'+'RETURN List <<'+' [/COLOR]','','http://png-4.findicons.com/files/icons/1714/dropline_neu/128/edit_undo.png')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
        exec_version = float(str(xbmc.getInfoLabel("System.BuildVersion"))[0:4])
        if exec_version < 14.0:
            playlist()
        else:
            playlist2()
    match94=re.compile('style\="width.*?" src\="(.*?)">').findall(link)
    for url in match94:
        if ".gif" in url:
            pass
        else:
            xbmcPlayer = xbmc.Player()
            playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playList.clear()
            addLink('[COLOR blue]'+'RETURN List <<'+' [/COLOR]','','http://png-4.findicons.com/files/icons/1714/dropline_neu/128/edit_undo.png')
            listitem = xbmcgui.ListItem(name)
            playList.add(url, listitem)
            xbmcPlayer.play(playList)
            exec_version = float(str(xbmc.getInfoLabel("System.BuildVersion"))[0:4])
            if exec_version < 14.0:
                    playlist()
            else:
                    playlist2()
    match95=re.compile('file: \'(.*?)\',\n\t\t\t\twidth').findall(link)
    for url in match95:
        yenical4(name,url)
#--
#42
def yenical4(name,url):
    xbmcPlayer = xbmc.Player() 
    playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
    playList.clear() 
    addLink(name,url,'')
    listitem = xbmcgui.ListItem(name) 
    playList.add(url, listitem) 
    xbmcPlayer.play(playList)
#--
#99
def magix_player(name,url):
        if "www.dailymotion.com" in url:
            fix.daily_sec(name,url)
##        elif "mail." in url:
##            MailRu_Player(url)
##        elif "ok." in url:
##            ok_ru(url)
        else:
            UrlResolverPlayer = url
            playList.clear()
            media = urlresolver.HostedMediaFile(UrlResolverPlayer)
            source = media
            if source:
                url = source.resolve()
                addLink(name,url,'')
                playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
#--
#29
def ayrisdirm1(url):
    link=get_url(url)
    try:
        ply=re.compile('\/pusuk\/url\/(.*?)"').findall(link)
        for name in ply:
            name=name.replace('?mode=flash','')
            name=base64.b64decode(name)
            reverseName=""
            for x in range(len(name)-1,-1,-1):
                    reverseName+=name[x]
            reverseName=base64.b64decode(reverseName)
            reverseName=reverseName.replace('ok/','')
            url=reverseName
            url = 'http://ok.ru/videoembed/'+str(url).encode('utf-8', 'ignore')
            magix_player(name,url)
        ply1=re.compile('\/pusuk\/url\/(.*?)=').findall(link)
        for name in ply1:
            name=name+'='
            name=base64.b64decode(name)
            reverseName=""
            for x in range(len(name)-1,-1,-1):
                    reverseName+=name[x]
            reverseName=base64.b64decode(reverseName)
            url=reverseName
            url=url.replace('/mail','')
            url = 'http://videoapi.my.mail.ru/videos/embed/'+url+'.html'
            magix_player(name,url)
    except:
        pass
    
    req = urllib2.Request(url)
    req.add_header("User-Agent","Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.99 Safari/537.36")
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    hqq=re.compile('src="https://hqq.tv/(.*?)"').findall(link)
    for url in hqq:
        url = 'https://hqq.tv/'+url
        url=url.replace('#038;','')
        hqq(url)
    ply10=re.compile('src="http:\/\/www.ultrafilmizle.com\/player\/url\/(.*?)"').findall(link)
    for name in ply10:
        name=base64.b64decode(name)
        reverseName=""
        for x in range(len(name)-1,-1,-1):
                reverseName+=name[x]
        reverseName=base64.b64decode(reverseName)
        reverseName=reverseName.replace('ok/','')
        url=reverseName
        value=[]
        url = 'http://ok.ru/videoembed/'+str(url)
        magix_player(name,url)
    ytt=re.compile('TEK PLUS--><br />\n<iframe width=".*?" height=".*?" src="(.*?)"').findall(link)
    for url in ytt:
        link=get_url(url)
        match=re.compile('file":"(.*?)"').findall(link)
        name='TEK PLUS Sec'
        for url in match:
            addLink('[COLOR beige][COLOR orange]>[/COLOR]'+name+'[/COLOR]',url,'')
    yt=re.compile('youtube.com/embed/(.*?)"').findall(link)
    for code in yt:
        url = 'http://www.youtube.com/embed/'+code
        name='Fragman'
        magix_player(name,url)
    ok2=re.compile('ok.ru\/videoembed\/(.*?)"').findall(link)
    for code in ok2:
        url = 'http://ok.ru/videoembed/'+str(code)
        name='OK RU  '
        magix_player(name,url)
    vk_2=re.compile('video_ext.php\?oid\=(.*?)"').findall(link) 
    for code in vk_2:
        url = 'http://vk.com/video_ext.php?oid='+str(code)
        url=url.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
        name='Vk - Play'
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,1030,'',"")
    mailru2=re.compile('videos\/embed\/mail\/(.*?).html').findall(link)
    for code in mailru2:
        url = 'http://videoapi.my.mail.ru/videos/embed/mail/'+str(code)+'.html'
        name='mail RU  '
        addDir('[COLOR blue]'+name+'[/COLOR]',url,99,"","")
    mailru22=re.compile('https://my.mail.ru/(.*?)\' width=').findall(link)
    for url in mailru22:
        url = 'https://my.mail.ru/'+url
        link=get_url(url)
        match=re.compile('movieSrc":"mail/(.*?)","metadataUrl').findall(link)
        for url in match:
            url = 'http://videoapi.my.mail.ru/videos/embed/mail/'+str(url)+'.html'
            name='mail RU  '
            magix_player(name,url)
    upto=re.compile('src="http://uptostream.com/iframe/(.*?)"').findall(link)
    for url in upto:
        url = 'http://uptostream.com/iframe/'+url
        name='play'
        magix_player(name,url)
    vidag=re.compile('http://vid.ag/(.*?)"').findall(link) 
    for url in vidag: 
        url = 'http://vid.ag/'+str(url).encode('utf-8', 'ignore')
        name='Play'
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,99,"",'')
    dd=re.compile('src="http://videomega.tv/view.php\?ref\=(.*?)\&width').findall(link) 
    for url in dd: 
        url = 'http://videomega.tv/view.php?ref='+str(url).encode('utf-8', 'ignore')
        name='Play'
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,99,"",'')
    ddo=re.compile('src="https://openload.co/embed/(.*?)"').findall(link) 
    for url in ddo: 
        url = 'https://openload.co/embed/'+str(url).encode('utf-8', 'ignore')
        name='Play'
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,99,"",'')
    vk_9=re.compile('video_ext.php\?oid\=(.*?)"').findall(link) 
    for url in vk_9: 
        url = 'http://vk.com/video_ext.php?oid='+str(url).encode('utf-8', 'ignore')
        name='Play'
        url=url.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
        addDir('[COLOR yellow]'+name+'[/COLOR]',url,1030,"",'')
#22
def frame(url):
    name='Play'
    link=get_url(url)
    match=re.compile('class="c5"><p><iframe src="(.*?)"').findall(link)
    for url in match:
        dizividcal(url)
    matchc=re.compile('<iframe src="(.*?)"  width=').findall(link)
    for url in matchc:
        if "reklam" in url:
            pass
        else:
            dizividcal(url)
    matcha=re.compile('src="http://www.daily(.*?)\?').findall(link)
    for url in matcha:
        url='http://www.daily'+url
        dizividcal(url)
    matchaa=re.compile('youtube.*?\/embed\/(.*?)\?').findall(link)
    for url in matchaa:
        url='http://www.youtube.com/embed/'+url
        name='Play-Youtube'
        magix_player(name,url)
    matchab=re.compile('ok.ru\/videoembed\/(.*?)"').findall(link)
    for url in matchab:
        url='http://ok.ru/videoembed/'+str(url)
        magix_player(name,url)
    ply1=re.compile("videoseyredin.net/embed/(.*?)'").findall(link)
    for url in ply1:
        url='https://www.videoseyredin.net/embed/'+url
        dizividcal(url)
    ply2=re.compile('/playlist/(.*?).json"').findall(link)
    for url in ply2:
        url='https://www.videoseyredin.net/playlist/'+url+'.json'
        dizividcal(url)
    vk=re.compile('vk.com\/(.*?)"').findall(link)
    for url in vk:
        url='http://vk.com/'+url
        url=url.replace('&#038;','&')
        magix_player(name,url)
    okru2=re.compile('".*?\/player\/ok\/1.*?\.php\?v\=(.*?)"').findall(link)
    for url in okru2:
      url=(base64.b64decode(url))
      url=url.replace("http://ok.ru/video/","")
      url='http://ok.ru/videoembed/'+str(url)
      magix_player(name,url)
    itt=re.compile('src="https:\/\/ittir.in\/v\/(.*?)"').findall(link)
    for url in itt:
        url=url.replace('https://ittir.in/v/','')
        url='http://dreamtr.club/a_n_d/ornek.php?no='+url
        link=get_url(url)
        match=re.compile('file": ".*?\.googlevideo.com(.*?)",\n                "label": "(.*?)",\n                "type": "mp4"').findall(link)
        for urlA,name in match:
            urlA=urlA.replace('\/','/').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
            addLink('[COLOR gold] KALITE SeC >>  '+'[COLOR beige]'+name+'[/COLOR]'+'[/COLOR]','https://redirector.googlevideo.com'+urlA,'')
        
        
#24   
def dizividcal(url):
    if "daily" in url:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('"video\\\/mp4","url"\:"(.*?)\/H264\-(.*?)\\\/video(.*?)"').findall(link)
        for a,name2,c in match:
            urlA=a+"/H264-"+name2+"/video"+c
            urlA=urlA.replace('\/','/')
            addLink('[COLOR gold] KALITE SeC >>  '+'[COLOR beige]'+name2+'[/COLOR]'+'[/COLOR]',urlA,'')
    if "itti" in url:
        url=url.replace('https://ittir.in/v/','')
        url='http://dreamtr.club/a_n_d/ornek.php?no='+url
        link=get_url(url)
        match=re.compile('file": ".*?\.googlevideo.com(.*?)",\n                "label": "(.*?)",\n                "type": "mp4"').findall(link)
        for urlA,name in match:
            urlA=urlA.replace('\/','/').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
            addLink('[COLOR gold] KALITE SeC >>  '+'[COLOR beige]'+name+'[/COLOR]'+'[/COLOR]','https://redirector.googlevideo.com'+urlA,'')
    if "oynat" in url:
        link=get_url(url)
        match4=re.compile('{"file":"(.*?)", "label":"(.*?)"').findall(link)
        for url,name in match4:
            addLink('[COLOR beige]'+name+'[/COLOR]',url,'')
    if "videoseyredin" in url:
        link=get_url(url)
        match1=re.compile('file":"(.*?)","type":"mp4","label":"(.*?)"').findall(link)
        for url,name in match1:
            name="[COLOR orange]Kalite SEC > [/COLOR]"+name
            if "err" in name:
                pass
            else:
                addLink('[COLOR beige][COLOR orange]>[/COLOR]'+name+'[/COLOR]',url,'')
    if "videoseyredin" in url:
        link=get_url(url)
        match1=re.compile('file:"(.*?)",label:"(.*?)p').findall(link)
        for url,name in match1:
            name="[COLOR orange]Kalite SEC > [/COLOR]"+name
            if "err" in name:
                pass
            else:
                url=url.replace('","default":"true','')
                addLink('[COLOR beige][COLOR orange]>[/COLOR]'+name+'[/COLOR]',url,'')
    if "videoseyredin" in url:
        link=get_url(url)
        ply2=re.compile('/playlist/(.*?).json"').findall(link)
        for url in ply2:
            url='https://www.videoseyredin.net/playlist/'+url+'.json'
            link=get_url(url)
            match=re.compile('file": ".*?\.googlevideo.com(.*?)",\n                "label": "(.*?)",\n                "type": "mp4"').findall(link)
            for urlA,name in match:
                urlA=urlA.replace('\/','/').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
                addLink('[COLOR gold] KALITE SeC >>  '+'[COLOR beige]'+name+'[/COLOR]'+'[/COLOR]','https://redirector.googlevideo.com'+urlA,'')


















































































































































































